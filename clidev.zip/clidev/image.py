"""Render images and video frames inside the terminal using colored block characters.

Uses the Unicode upper-half-block character (▀) with independent
foreground/background truecolor, so each terminal cell shows two
vertically-stacked pixels — doubling effective vertical resolution.

Requires:
    pip install Pillow            # for TerminalImage
    pip install opencv-python     # for TerminalVideo (optional)

Usage:
    app.image("photo.png").show()
    app.image("photo.png", size="large").show()
    app.video("clip.mp4").play()
    app.video("clip.mp4", size="small", fps=24).play()
"""

import shutil
import time

from rich.console import Console

from .exceptions import ClidevError

try:
    from PIL import Image as PILImage
except ImportError:  # pragma: no cover
    PILImage = None

try:
    import cv2
except ImportError:  # pragma: no cover
    cv2 = None

_UPPER_HALF_BLOCK = "\u2580"  # ▀

# Named size presets, in terminal columns. "auto" falls back to the
# terminal's current width (capped so huge terminals don't render enormous
# frames that are slow to draw).
SIZE_PRESETS = {
    "small": 40,
    "medium": 80,
    "large": 120,
}

_DEFAULT_FPS = 24


def _resolve_width(size: str | None, width: int | None, cap: int) -> int:
    """Resolve an explicit width, a named size preset, or fall back to
    the terminal's current width (capped at `cap`)."""
    if width:
        return width
    if size:
        key = size.lower()
        if key not in SIZE_PRESETS:
            raise ClidevError(
                f"Unknown size '{size}'. Choose from: {list(SIZE_PRESETS)}, "
                "or pass an explicit width=<int>."
            )
        return SIZE_PRESETS[key]
    terminal_width = shutil.get_terminal_size(fallback=(80, 24)).columns
    return min(terminal_width, cap)


class TerminalImage:
    """Render a static image as colored terminal blocks.

    app.image("photo.png").show()
    app.image("photo.png", size="large").show()
    app.image("photo.png", width=60).show()   # explicit width overrides size
    """

    def __init__(self, path: str, size: str | None = "medium", width: int | None = None,
                 console: Console | None = None):
        """
        Args:
            path: Path to the image file.
            size: One of "small" (40 cols), "medium" (80 cols), "large"
                  (120 cols). Ignored if `width` is given.
            width: Explicit width in terminal columns. Overrides `size`.
            console: Optional rich Console to print to.
        """
        if PILImage is None:
            raise ClidevError(
                "Pillow is required to render images. Install it with: pip install Pillow"
            )
        self.path = path
        self.size = size
        self.width = width
        self._console = console or Console()

    def _target_width(self) -> int:
        return _resolve_width(self.size, self.width, cap=120)

    def _load_pixels(self):
        img = PILImage.open(self.path).convert("RGB")
        target_width = self._target_width()
        aspect_ratio = img.height / img.width
        # x2 rows so we can pair them into upper/lower half-block pixels.
        target_height = max(2, int(target_width * aspect_ratio * 0.5) * 2)
        return img.resize((target_width, target_height))

    def render(self) -> str:
        img = self._load_pixels()
        width, height = img.size
        pixels = img.load()
        lines = []
        for y in range(0, height - 1, 2):
            parts = []
            for x in range(width):
                tr, tg, tb = pixels[x, y]
                br, bg, bb = pixels[x, y + 1]
                parts.append(
                    f"[rgb({tr},{tg},{tb}) on rgb({br},{bg},{bb})]{_UPPER_HALF_BLOCK}[/]"
                )
            lines.append("".join(parts))
        return "\n".join(lines)

    def show(self):
        self._console.print(self.render())


class TerminalVideo:
    """Play a video inline in the terminal as a sequence of colored-block frames.

    app.video("clip.mp4").play()                       # plays at 24 fps by default
    app.video("clip.mp4", size="small").play()          # smaller = faster to render
    app.video("clip.mp4", fps=30).play(max_frames=200)

    Frame timing is measured with a monotonic clock and accounts for how
    long each frame actually took to render, so playback stays close to
    the target fps instead of drifting slower the longer it plays.
    """

    def __init__(self, path: str, size: str | None = "medium", width: int | None = None,
                 fps: float | None = None, console: Console | None = None):
        """
        Args:
            path: Path to the video file.
            size: One of "small" (40 cols), "medium" (80 cols), "large"
                  (100 cols). Ignored if `width` is given. Smaller sizes
                  render faster, which helps keep pace with real fps.
            width: Explicit width in terminal columns. Overrides `size`.
            fps: Target playback frame rate. Defaults to 24, a good
                 baseline for smooth-looking terminal playback; pass the
                 source video's own fps (see `.source_fps`) to match it
                 exactly instead.
            console: Optional rich Console to print to.
        """
        if cv2 is None:
            raise ClidevError(
                "opencv-python is required to render video. "
                "Install it with: pip install opencv-python"
            )
        self.path = path
        self.size = size
        self.width = width
        self.fps_override = fps
        self._console = console or Console()
        self.source_fps: float | None = None

    def _target_width(self) -> int:
        return _resolve_width(self.size, self.width, cap=100)

    def _frame_to_text(self, frame) -> str:
        height_px, width_px = frame.shape[:2]
        target_width = self._target_width()
        aspect_ratio = height_px / width_px
        target_height = max(2, int(target_width * aspect_ratio * 0.5) * 2)

        frame = cv2.resize(frame, (target_width, target_height))
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        lines = []
        for y in range(0, frame.shape[0] - 1, 2):
            parts = []
            for x in range(frame.shape[1]):
                tr, tg, tb = frame[y, x]
                br, bg, bb = frame[y + 1, x]
                parts.append(
                    f"[rgb({tr},{tg},{tb}) on rgb({br},{bg},{bb})]{_UPPER_HALF_BLOCK}[/]"
                )
            lines.append("".join(parts))
        return "\n".join(lines)

    def play(self, max_frames: int | None = None, skip: int = 1):
        """Play the video.

        Args:
            max_frames: stop after this many rendered frames (None = whole video).
            skip: render every Nth source frame. Increase this if the source
                  video's native fps is much higher than your target fps
                  (e.g. a 60fps source played at a 24fps target).
        """
        capture = cv2.VideoCapture(self.path)
        if not capture.isOpened():
            raise ClidevError(f"Could not open video file: {self.path}")

        self.source_fps = capture.get(cv2.CAP_PROP_FPS) or _DEFAULT_FPS
        target_fps = self.fps_override or _DEFAULT_FPS
        frame_interval = 1 / target_fps

        frame_index = 0
        rendered = 0
        next_frame_time = time.perf_counter()

        try:
            with self._console.screen():
                while True:
                    ok, frame = capture.read()
                    if not ok:
                        break

                    if frame_index % skip == 0:
                        rendered_text = self._frame_to_text(frame)

                        # Sleep only for whatever time is left before the
                        # next frame is due, so rendering time is
                        # accounted for and playback doesn't drift slow.
                        now = time.perf_counter()
                        sleep_for = next_frame_time - now
                        if sleep_for > 0:
                            time.sleep(sleep_for)

                        self._console.print(rendered_text)
                        rendered += 1
                        next_frame_time += frame_interval

                        if max_frames and rendered >= max_frames:
                            break

                    frame_index += 1
        finally:
            capture.release()