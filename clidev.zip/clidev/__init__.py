"""
clidev
======

A framework for building production-ready CLI applications and Terminal
User Interfaces (TUIs) with minimal code.

    from clidev import App

    app = App("My App")
    home = app.menu("Home")
    home.option("Exit", app.exit)
    app.run()
"""

from .app import App
from .banner import Banner
from .cards import Card
from .dashboard import Dashboard
from .dialogs import Dialog
from .events import EventDispatcher
from .exceptions import (
    ClidevError,
    CommandError,
    NavigationError,
    PluginError,
    StorageError,
    ValidationError,
    WorkflowError,
)
from .image import TerminalImage, TerminalVideo
from .forms import Form
from .menus import Menu
from .plugins import Plugin
from .router import Router
from .state import State
from .storage import Storage
from .table import Table
from .themes import Theme
from .tree import Tree
from .workflow import Workflow

__version__ = "0.1.0"

__all__ = [
    "App",
    "Banner",
    "Card",
    "Dashboard",
    "Dialog",
    "EventDispatcher",
    "ClidevError",
    "CommandError",
    "NavigationError",
    "PluginError",
    "StorageError",
    "ValidationError",
    "WorkflowError",
    "Form",
    "Menu",
    "Plugin",
    "Router",
    "State",
    "Storage",
    "Table",
    "Theme",
    "TerminalImage",
    "TerminalVideo",
    "Tree",
    "Workflow",
    "__version__",
]
