"""The core App class -- the main entry point for every clidev application."""

import sys

from rich.console import Console

from .actions import ConditionBuilder, when as _when
from .cards import Card
from .config import Config
from .dashboard import Dashboard
from .dialogs import Dialog
from .events import EventDispatcher
from .exceptions import ClidevError
from .forms import Form
from .logger import Logger
from .menus import Menu
from .notifications import Notifications
from .plugins import PluginManager
from .progress import ProgressContext
from .router import Router
from .scheduler import Scheduler
from .shell import Shell
from .spinner import Spinner
from .state import State
from .statusbar import StatusBar
from .storage import Storage
from .table import Table
from .tasks import TaskRegistry
from .themes import Theme
from .tree import Tree
from .workflow import Workflow


class App:
    """The main application object.

    app = App("My App")
    home = app.menu("Home")
    home.option("Exit", app.exit)
    app.run()
    """

    def __init__(self, title: str = "clidev App", theme: str | Theme = "dark",
                 storage_backend: str = "memory", **config_kwargs):
        self.title = title
        self.console = Console()
        self.config = Config(theme=theme if isinstance(theme, str) else "custom", **config_kwargs)

        self.theme = theme if isinstance(theme, Theme) else Theme.preset(theme)
        self.logger = Logger(theme=self.theme, console=self.console,
                              timestamps=self.config.log_timestamps)
        self.state = State()
        self.storage = Storage(backend=storage_backend)
        self.events = EventDispatcher()
        self.router = Router(app=self)
        self.tasks = TaskRegistry()
        self.scheduler = Scheduler()
        self.plugins = PluginManager(app=self)
        self.shell = Shell()
        self.notify = Notifications(theme=self.theme, console=self.console)
        self.dialog = Dialog(theme=self.theme)
        self.statusbar = StatusBar(theme=self.theme, console=self.console)

        self._should_exit = False
        self._last_form_data: dict = {}
        self._main_menu: Menu | None = None

    # ------------------------------------------------------------------
    # UI factories
    # ------------------------------------------------------------------
    def menu(self, title: str = "Menu") -> Menu:
        m = Menu(title=title, app=self)
        if self._main_menu is None:
            self._main_menu = m
        return m

    def form(self, title: str = "Form") -> Form:
        return Form(title=title, app=self)

    def table(self, title: str = "", columns: list[str] | None = None) -> Table:
        return Table(title=title, columns=columns, theme=self.theme)

    def tree(self, label: str) -> Tree:
        return Tree(label)

    def card(self, title: str, content: str = "") -> Card:
        return Card(title, content, theme=self.theme)

    def dashboard(self, title: str = "Dashboard") -> Dashboard:
        return Dashboard(title, theme=self.theme)

    def workflow(self, name: str = "workflow") -> Workflow:
        return Workflow(app=self, name=name)

    def progress(self, label: str = "Working", total: int | None = None) -> ProgressContext:
        return ProgressContext(label=label, total=total)

    def spinner(self, label: str = "Loading...") -> Spinner:
        return Spinner(label=label, console=self.console)

    # ------------------------------------------------------------------
    # Navigation / pages
    # ------------------------------------------------------------------
    def page(self, name: str, handler=None):
        return self.router.page(name, handler)

    def goto(self, name: str, *args, **kwargs):
        return self.router.goto(name, *args, **kwargs)

    def back(self):
        return self.router.back()

    # ------------------------------------------------------------------
    # Conditional navigation
    # ------------------------------------------------------------------
    def if_value(self, key: str, **comparisons) -> ConditionBuilder:
        return ConditionBuilder(self, self._last_form_data, key, **comparisons)

    def when(self, condition_fn):
        return _when(condition_fn)

    # ------------------------------------------------------------------
    # Events
    # ------------------------------------------------------------------
    def on_start(self, fn):
        return self.events.on("start", fn)

    def on_exit(self, fn):
        return self.events.on("exit", fn)

    def on_error(self, fn):
        return self.events.on("error", fn)

    def on_submit(self, form: Form):
        """Decorator: @app.on_submit(some_form) def handler(data): ..."""

        def decorator(fn):
            def wrapped(data):
                self._last_form_data = data
                return fn(data)

            self.events.on(f"submit:{form.id}", wrapped)
            return fn

        return decorator

    # ------------------------------------------------------------------
    # Shell / tasks / plugins
    # ------------------------------------------------------------------
    def cmd(self, command: str, capture: bool = False, background: bool = False,
            check: bool = False, cwd: str | None = None):
        return self.shell.run(command, capture=capture, background=background,
                               check=check, cwd=cwd)

    def task(self, fn=None, *, name: str | None = None):
        return self.tasks.register(fn, name=name)

    def run_task(self, name: str, *args, **kwargs):
        return self.tasks.run(name, *args, **kwargs)

    def use(self, plugin):
        return self.plugins.use(plugin)

    # ------------------------------------------------------------------
    # Notifications shortcuts
    # ------------------------------------------------------------------
    def success(self, message: str):
        self.notify.success(message)

    def error(self, message: str):
        self.notify.error(message)

    def warning(self, message: str):
        self.notify.warning(message)

    def info(self, message: str):
        self.notify.info(message)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def exit(self, *args, **kwargs):
        """Register as a menu handler or call directly to stop the app loop."""
        if self.config.confirm_exit:
            if not self.dialog.confirm_exit():
                return
        self._should_exit = True
        self.events.emit("exit")
        self.plugins.exit_all()

    def run(self):
        try:
            self.events.emit("start")
            self.plugins.start_all()
            if self._main_menu is not None:
                self._main_menu.run()
        except (KeyboardInterrupt, EOFError):
            self.console.print()
            self.info("Interrupted. Exiting.")
        except ClidevError as e:
            self.events.emit("error", e)
            self.error(str(e))
            sys.exit(1)
        finally:
            if not self._should_exit:
                self.events.emit("exit")
                self.plugins.exit_all()

    def __repr__(self):
        return f"App(title={self.title!r})"
