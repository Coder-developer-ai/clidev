"""Plugin system: app.use(SomePlugin())."""

from .exceptions import PluginError


class Plugin:
    """Base class for clidev plugins.

    Subclass and override the lifecycle hooks you need:

    class GitPlugin(Plugin):
        name = "git"

        def on_install(self, app):
            app.state["git_enabled"] = True

        def on_start(self, app):
            ...
    """

    name: str = "plugin"

    def on_install(self, app):
        """Called once, immediately when app.use(plugin) runs."""

    def on_start(self, app):
        """Called when the app starts (app.run())."""

    def on_exit(self, app):
        """Called when the app exits."""


class PluginManager:
    def __init__(self, app=None):
        self.app = app
        self.plugins: list[Plugin] = []

    def use(self, plugin: Plugin):
        if not isinstance(plugin, Plugin):
            raise PluginError(f"{plugin!r} must be a Plugin instance.")
        self.plugins.append(plugin)
        plugin.on_install(self.app)
        return plugin

    def start_all(self):
        for p in self.plugins:
            p.on_start(self.app)

    def exit_all(self):
        for p in self.plugins:
            p.on_exit(self.app)
