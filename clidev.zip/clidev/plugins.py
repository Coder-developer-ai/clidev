"""Plugin system: app.use(SomePlugin())."""

from .exceptions import PluginError


class Plugin:
    """Base class for clidev plugins.

    Subclass and override whichever lifecycle hooks you need — you don't
    have to implement all of them.

    class GitPlugin(Plugin):
        name = "git"
        priority = 0   # lower runs first; ties broken by registration order

        def on_install(self, app):
            app.state["git_enabled"] = True

        def on_start(self, app):
            ...

        def on_page(self, app, page_name):
            ...

        def on_submit(self, app, form_title, data):
            ...

        def on_command(self, app, command, result):
            ...

        def on_error(self, app, error):
            ...

        def on_exit(self, app):
            ...
    """

    name: str = "plugin"
    priority: int = 100  # lower = runs earlier
    enabled: bool = True

    def on_install(self, app):
        """Called once, immediately when app.use(plugin) runs."""

    def on_start(self, app):
        """Called when the app starts (app.run())."""

    def on_page(self, app, page_name: str):
        """Called every time the app navigates to a page (app.goto(name))."""

    def on_submit(self, app, form_title: str, data: dict):
        """Called every time a form is submitted, with its title and data."""

    def on_command(self, app, command: str, result):
        """Called after every shell command runs (app.cmd(...)).

        `result` is the CommandResult (or BackgroundHandle for background
        commands) returned by the command.
        """

    def on_error(self, app, error: Exception):
        """Called whenever an error is emitted through app.events."""

    def on_exit(self, app):
        """Called when the app exits."""


class PluginManager:
    """Tracks registered plugins and dispatches lifecycle hooks to them.

    Plugins run in `priority` order (lowest first), then registration order
    for ties. Disabled plugins are skipped without being removed, so they
    can be re-enabled later.
    """

    _HOOK_NAMES = (
        "on_install", "on_start", "on_page", "on_submit",
        "on_command", "on_error", "on_exit",
    )

    def __init__(self, app=None):
        self.app = app
        self.plugins: list[Plugin] = []

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------
    def use(self, plugin: Plugin) -> Plugin:
        """Register and install a plugin. Returns the plugin for chaining."""
        if not isinstance(plugin, Plugin):
            raise PluginError(f"{plugin!r} must be a Plugin instance.")
        self.plugins.append(plugin)
        self._resort()
        self._dispatch_one(plugin, "on_install", self.app)
        return plugin

    def remove(self, plugin: Plugin):
        """Permanently unregister a plugin."""
        if plugin in self.plugins:
            self.plugins.remove(plugin)

    def get(self, name: str) -> Plugin | None:
        """Look up a registered plugin by its `name` attribute."""
        for plugin in self.plugins:
            if plugin.name == name:
                return plugin
        return None

    def enable(self, name: str):
        plugin = self.get(name)
        if plugin is not None:
            plugin.enabled = True

    def disable(self, name: str):
        """Temporarily stop a plugin from receiving hook calls, without
        removing it (so it can be re-enabled later via .enable())."""
        plugin = self.get(name)
        if plugin is not None:
            plugin.enabled = False

    def _resort(self):
        self.plugins.sort(key=lambda p: p.priority)

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------
    def _dispatch_one(self, plugin: Plugin, hook_name: str, *args, **kwargs):
        if not plugin.enabled:
            return
        hook = getattr(plugin, hook_name, None)
        if hook is None:
            return
        try:
            hook(*args, **kwargs)
        except Exception as e:
            raise PluginError(
                f"Plugin '{plugin.name}' raised an error in {hook_name}: {e}"
            ) from e

    def dispatch(self, hook_name: str, *args, **kwargs):
        """Fire `hook_name` on every enabled plugin, in priority order."""
        if hook_name not in self._HOOK_NAMES:
            raise PluginError(f"Unknown plugin hook: '{hook_name}'")
        for plugin in self.plugins:
            self._dispatch_one(plugin, hook_name, self.app, *args, **kwargs)

    # ------------------------------------------------------------------
    # Convenience wrappers for the most common lifecycle points
    # ------------------------------------------------------------------
    def start_all(self):
        self.dispatch("on_start")

    def exit_all(self):
        self.dispatch("on_exit")

    def page_all(self, page_name: str):
        self.dispatch("on_page", page_name)

    def submit_all(self, form_title: str, data: dict):
        self.dispatch("on_submit", form_title, data)

    def command_all(self, command: str, result):
        self.dispatch("on_command", command, result)

    def error_all(self, error: Exception):
        self.dispatch("on_error", error)