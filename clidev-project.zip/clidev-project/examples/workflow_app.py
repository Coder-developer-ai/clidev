"""
Example demonstrating the workflow engine, plugins, tasks, and dashboard.

Run with:
    python examples/workflow_app.py
"""

from clidev import App
from clidev.plugins import Plugin


class GreetingPlugin(Plugin):
    name = "greeting"

    def on_start(self, app):
        app.logger.info("GreetingPlugin says hello!")


app = App("Deploy Pipeline", theme="dark")
app.use(GreetingPlugin())


def login(context):
    app.info("Logging in...")
    return {"logged_in": True}


def select_project(context):
    assert context["logged_in"]
    app.info("Selecting project...")
    return {"project": "clidev-demo"}


def build(context):
    app.info(f"Building {context['project']}...")
    return {"build_ok": True}


def deploy(context):
    assert context["build_ok"]
    app.success(f"Deployed {context['project']}!")
    return {"deployed": True}


@app.task
def show_dashboard():
    dash = app.dashboard("Pipeline Status")
    dash.panel("Project", app.state.get("project", "n/a"))
    dash.panel("Status", "Deployed" if app.state.get("deployed") else "Pending")
    dash.show()


if __name__ == "__main__":
    pipeline = app.workflow("deploy_pipeline")
    pipeline.step(login).step(select_project).step(build).step(deploy)
    result = pipeline.start()
    app.state.update(result)
    app.run_task("show_dashboard")
