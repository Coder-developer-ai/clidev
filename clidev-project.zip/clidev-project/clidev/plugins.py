

import warnings
from typing import Any, Callable

from .exceptions import PluginError


class Plugin:
  

    name: str = "plugin"
    version: str = "0.1.0"
    description: str = ""
    priority: int = 100          
    enabled: bool = True
    requires: list[str] = []     

    def __init__(self, **config):
        self.config: dict[str, Any] = config
        self.app = None  # set automatically by PluginManager on install

    def get(self, key: str, default=None):
        
        return self.config.get(key, default)

    def on_install(self, app):
        """Called once, immediately when app.use(plugin) runs."""

    def on_start(self, app):
        """Called when the app starts (app.run())."""

    def on_page(self, app, page_name: str):
        """Called every time the app navigates to a page (app.goto(name))."""

    def on_submit(self, app, form_title: str, data: dict):
        """Called every time a form is submitted, with its title and data."""

    def on_command(self, app, command: str, result):
        """Called after every shell command runs (app.cmd(...)).

        `result` is the CommandResult (or BackgroundHandle for background
        commands) returned by the command.
        """

    def on_error(self, app, error: Exception):
        """Called whenever an error is emitted through app.events."""

    def on_exit(self, app):
        """Called when the app exits."""

    def __repr__(self):
        return f"<Plugin {self.name} v{self.version}>"


class FunctionalPlugin(Plugin):
    

    def __init__(self, name: str, priority: int = 100, requires: list[str] | None = None,
                 **hooks: Callable):
        super().__init__()
        self.name = name
        self.priority = priority
        self.requires = requires or []
        for hook_name, fn in hooks.items():
            setattr(self, hook_name, fn)


class PluginManager:
  

    def __init__(self, app=None, strict: bool = False):
        
        self.app = app
        self.strict = strict
        self.plugins: list[Plugin] = []
        self.shared: dict[str, Any] = {}  # scratch space for inter-plugin data
        self._registry: dict[str, type] = {}

  
    def register_class(self, name: str, plugin_cls: type):
        if not (isinstance(plugin_cls, type) and issubclass(plugin_cls, Plugin)):
            raise PluginError(f"{plugin_cls!r} must be a Plugin subclass.")
        self._registry[name] = plugin_cls

    def available(self) -> list[str]:
        """Names of plugin classes registered globally and available to `use()`."""
        return list(self._registry.keys())

    def create(self, name: str, **config) -> Plugin:
        if name not in self._registry:
            raise PluginError(
                f"No plugin class registered under '{name}'. "
                f"Available: {self.available()}"
            )
        return self._registry[name](**config)


    def use(self, plugin, **config) -> Plugin:
       
        if isinstance(plugin, str):
            plugin = self.create(plugin, **config)
        elif isinstance(plugin, type) and issubclass(plugin, Plugin):
            plugin = plugin(**config)
        elif config and isinstance(plugin, Plugin):
            plugin.config.update(config)

        if not isinstance(plugin, Plugin):
            raise PluginError(f"{plugin!r} must be a Plugin instance, subclass, or registered name.")

        if self.get(plugin.name) is not None:
            raise PluginError(f"A plugin named '{plugin.name}' is already installed.")

        self._check_dependencies(plugin)
        plugin.app = self.app
        self.plugins.append(plugin)
        self._resort()
        self._dispatch_one(plugin, "on_install", self.app)
        return plugin

    def _check_dependencies(self, plugin: Plugin):
        installed_names = {p.name for p in self.plugins}
        missing = [dep for dep in plugin.requires if dep not in installed_names]
        if missing:
            raise PluginError(
                f"Plugin '{plugin.name}' requires {missing} to be installed first "
                f"(use app.use(...) for each dependency before this one)."
            )

    def remove(self, plugin_or_name):
        """Permanently unregister a plugin, by instance or by name."""
        name = plugin_or_name if isinstance(plugin_or_name, str) else plugin_or_name.name
        self.plugins = [p for p in self.plugins if p.name != name]

    def get(self, name: str) -> Plugin | None:
        """Look up an installed plugin by its `name` attribute."""
        for plugin in self.plugins:
            if plugin.name == name:
                return plugin
        return None

    def has(self, name: str) -> bool:
        return self.get(name) is not None

    def enable(self, name: str):
        plugin = self.get(name)
        if plugin is not None:
            plugin.enabled = True

    def disable(self, name: str):
        """Temporarily stop a plugin from receiving hook calls, without
        removing it (so it can be re-enabled later via .enable())."""
        plugin = self.get(name)
        if plugin is not None:
            plugin.enabled = False

    def _resort(self):
        self.plugins.sort(key=lambda p: p.priority)

    def _dispatch_one(self, plugin: Plugin, hook_name: str, *args, **kwargs):
        if not plugin.enabled:
            return None
        hook = getattr(plugin, hook_name, None)
        if hook is None or not callable(hook):
            return None
        try:
            return hook(*args, **kwargs)
        except Exception as e:
            error = PluginError(f"Plugin '{plugin.name}' raised an error in {hook_name}: {e}")
            if self.strict:
                raise error from e
            if self.app is not None and getattr(self.app, "logger", None):
                self.app.logger.error(str(error))
            else:
                warnings.warn(str(error))
            return None

    def dispatch(self, hook_name: str, *args, **kwargs) -> dict[str, Any]:
      
        results = {}
        for plugin in self.plugins:
            result = self._dispatch_one(plugin, hook_name, self.app, *args, **kwargs)
            if result is not None:
                results[plugin.name] = result
        return results

    def start_all(self):
        self.dispatch("on_start")

    def exit_all(self):
        self.dispatch("on_exit")

    def page_all(self, page_name: str):
        self.dispatch("on_page", page_name)

    def submit_all(self, form_title: str, data: dict):
        self.dispatch("on_submit", form_title, data)

    def command_all(self, command: str, result):
        self.dispatch("on_command", command, result)

    def error_all(self, error: Exception):
        self.dispatch("on_error", error)

    def list_plugins(self) -> list[dict]:
        return [
            {
                "name": p.name,
                "version": p.version,
                "description": p.description,
                "priority": p.priority,
                "enabled": p.enabled,
                "requires": p.requires,
            }
            for p in self.plugins
        ]

    def __repr__(self):
        names = [p.name for p in self.plugins]
        return f"PluginManager(plugins={names}, strict={self.strict})"