"""Table rendering widget, wraps rich.table.Table."""

from rich.console import Console
from rich.table import Table as RichTable


class Table:
    """app.table("Users", columns=["Name", "Age"]).add_row("Bob", "30").show()"""

    def __init__(self, title: str = "", columns: list[str] | None = None, theme=None):
        self.title = title
        self.columns = columns or []
        self.rows: list[list] = []
        self.theme = theme
        self._console = Console()

    def add_column(self, name: str) -> "Table":
        self.columns.append(name)
        return self

    def add_row(self, *values) -> "Table":
        self.rows.append(list(values))
        return self

    def add_rows(self, rows: list[list]) -> "Table":
        self.rows.extend(rows)
        return self

    def build(self) -> RichTable:
        color = self.theme.get("primary") if self.theme else None
        rich_table = RichTable(title=self.title or None, header_style=f"bold {color}" if color else "bold")
        for col in self.columns:
            rich_table.add_column(col)
        for row in self.rows:
            rich_table.add_row(*[str(v) for v in row])
        return rich_table

    def show(self):
        self._console.print(self.build())
