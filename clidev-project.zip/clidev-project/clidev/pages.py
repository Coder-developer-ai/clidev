"""Page registration. Pages are named callables the router can navigate to."""


class Page:
    def __init__(self, name: str, handler=None):
        self.name = name
        self.handler = handler

    def render(self, *args, **kwargs):
        if self.handler is not None:
            return self.handler(*args, **kwargs)


class PageRegistry:
    """Holds all registered pages by name."""

    def __init__(self):
        self._pages: dict[str, Page] = {}

    def register(self, name: str, handler=None):
        """Register a page. Can be used directly or as a decorator:

        app.page("home")  -> returns a decorator when handler is None
        """
        if handler is not None:
            self._pages[name] = Page(name, handler)
            return self._pages[name]

        def decorator(fn):
            self._pages[name] = Page(name, fn)
            return fn

        return decorator

    def get(self, name: str) -> Page | None:
        return self._pages.get(name)

    def exists(self, name: str) -> bool:
        return name in self._pages

    def names(self):
        return list(self._pages.keys())
