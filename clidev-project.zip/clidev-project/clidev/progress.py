"""Progress bar context manager: with app.progress("Installing"): ..."""

from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn


class ProgressContext:
    """Context manager wrapping a rich Progress bar with one indeterminate task.

    with app.progress("Installing"):
        app.cmd("pip install numpy")
        app.cmd("pip install pandas")
    """

    def __init__(self, label: str = "Working", total: int | None = None):
        self.label = label
        self.total = total
        self._progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TimeElapsedColumn(),
        )
        self._task_id = None

    def __enter__(self):
        self._progress.start()
        self._task_id = self._progress.add_task(self.label, total=self.total)
        return self

    def advance(self, amount: float = 1):
        if self._task_id is not None:
            self._progress.update(self._task_id, advance=amount)

    def set_description(self, text: str):
        if self._task_id is not None:
            self._progress.update(self._task_id, description=text)

    def __exit__(self, exc_type, exc, tb):
        if self._task_id is not None and self.total:
            self._progress.update(self._task_id, completed=self.total)
        self._progress.stop()
        return False
