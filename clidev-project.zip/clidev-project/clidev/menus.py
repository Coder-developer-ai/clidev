"""Menu + nested menu engine."""

import questionary
from rich.console import Console
from rich.panel import Panel


class MenuOption:
    def __init__(self, label: str, target):
        self.label = label
        self.target = target  # callable, page name string, or Menu instance


class Menu:
    """A single-level (optionally nested) menu.

    menu = app.menu("Main Menu")
    menu.option("Create Project", create_project)
    menu.option("Deploy", deploy)
    menu.option("Exit", app.exit)

    Nested:
        main.link("Settings", settings_menu)
    """

    def __init__(self, title: str = "Menu", app=None):
        self.title = title
        self.app = app
        self.options: list[MenuOption] = []
        self._console = Console()

    def option(self, label: str, target) -> "Menu":
        """Add a menu entry. `target` can be a callable, a page-name string,
        or another Menu (equivalent to .link)."""
        self.options.append(MenuOption(label, target))
        return self

    def link(self, label: str, submenu: "Menu") -> "Menu":
        """Add a nested submenu entry."""
        self.options.append(MenuOption(label, submenu))
        return self

    def _resolve(self, target):
        if isinstance(target, Menu):
            target.run()
        elif isinstance(target, str):
            if self.app is not None:
                self.app.goto(target)
        elif callable(target):
            target()

    def run(self):
        """Render the menu in a loop until the user exits or a handler navigates away."""
        while True:
            self._console.print(Panel(f"[bold]{self.title}[/bold]", expand=False))
            choice = questionary.select(
                "Select an option:",
                choices=[opt.label for opt in self.options],
            ).ask()
            if choice is None:
                return
            selected = next(o for o in self.options if o.label == choice)
            self._resolve(selected.target)
            # If app signalled exit, stop looping.
            if self.app is not None and getattr(self.app, "_should_exit", False):
                return

    def __repr__(self):
        return f"Menu(title={self.title!r}, options={[o.label for o in self.options]})"
