"""Tree rendering widget, wraps rich.tree.Tree."""

from rich.console import Console
from rich.tree import Tree as RichTree


class TreeNode:
    def __init__(self, label: str):
        self.label = label
        self.children: list["TreeNode"] = []

    def add(self, label: str) -> "TreeNode":
        node = TreeNode(label)
        self.children.append(node)
        return node

    def _build(self, rich_node):
        for child in self.children:
            branch = rich_node.add(child.label)
            child._build(branch)


class Tree:
    """app.tree("Project"); root.add("src").add("main.py")"""

    def __init__(self, label: str):
        self.root = TreeNode(label)
        self._console = Console()

    def add(self, label: str) -> TreeNode:
        return self.root.add(label)

    def show(self):
        rich_tree = RichTree(self.root.label)
        self.root._build(rich_tree)
        self._console.print(rich_tree)
