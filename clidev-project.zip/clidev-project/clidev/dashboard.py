"""Dashboard: a simple grid layout of panels for at-a-glance views."""

from rich.console import Console
from rich.columns import Columns
from rich.panel import Panel


class Dashboard:
    """app.dashboard("Overview").panel("Users", "1,204").panel("Errors", "3").show()"""

    def __init__(self, title: str = "Dashboard", theme=None):
        self.title = title
        self.theme = theme
        self._panels: list[tuple[str, str]] = []
        self._console = Console()

    def panel(self, title: str, content: str) -> "Dashboard":
        self._panels.append((title, content))
        return self

    def show(self):
        color = self.theme.get("primary") if self.theme else "white"
        self._console.rule(f"[bold {color}]{self.title}[/bold {color}]")
        rendered = [
            Panel(str(content), title=title, border_style=color, expand=True)
            for title, content in self._panels
        ]
        self._console.print(Columns(rendered, equal=True, expand=True))
