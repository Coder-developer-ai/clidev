"""Inline notification / toast-style messages (success, error, info, warning)."""

from rich.console import Console


class Notifications:
    def __init__(self, theme=None, console: Console | None = None):
        self.theme = theme
        self.console = console or Console()

    def _print(self, symbol: str, style_key: str, message: str):
        color = self.theme.get(style_key) if self.theme else None
        style = f"bold {color}" if color else "bold"
        self.console.print(f"[{style}]{symbol}[/{style}] {message}")

    def success(self, message: str):
        self._print("\u2713", "success", message)

    def error(self, message: str):
        self._print("\u2717", "error", message)

    def warning(self, message: str):
        self._print("\u26A0", "warning", message)

    def info(self, message: str):
        self._print("\u2139", "info", message)
