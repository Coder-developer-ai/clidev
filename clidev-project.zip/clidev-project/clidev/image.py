"""Render images and video frames inside the terminal using colored block characters.

Uses the Unicode upper-half-block character (▀) with independent
foreground/background truecolor, so each terminal cell shows two
vertically-stacked pixels — doubling effective vertical resolution.

Supports loading from:
    - Local file paths
    - Direct URLs (http/https)
    - Google Drive share links (auto-converted to a direct download)

Requires:
    pip install Pillow            # for TerminalImage
    pip install opencv-python     # for TerminalVideo
    pip install requests          # for URL / Google Drive loading

Usage:
    app.image("photo.png").show()
    app.image("https://example.com/photo.png").show()
    app.image("https://drive.google.com/file/d/FILE_ID/view").show()

    app.video("clip.mp4").play()
    app.video("https://example.com/clip.mp4").play()
    app.video("https://drive.google.com/file/d/FILE_ID/view").play()
"""

import re
import shutil
import tempfile
import time
from pathlib import Path
from urllib.parse import urlparse, parse_qs

from rich.console import Console

from .exceptions import ClidevError

try:
    from PIL import Image as PILImage
except ImportError:  # pragma: no cover
    PILImage = None

try:
    import cv2
except ImportError:  # pragma: no cover
    cv2 = None

try:
    import requests
except ImportError:  # pragma: no cover
    requests = None

_UPPER_HALF_BLOCK = "\u2580"  # ▀

# Named size presets, in terminal columns.
SIZE_PRESETS = {
    "small": 40,
    "medium": 80,
    "large": 120,
}

_DEFAULT_FPS = 24
_GDRIVE_HOSTS = ("drive.google.com", "docs.google.com")


# ---------------------------------------------------------------------------
# Shared helpers: sizing, URL/Drive resolution, temp file management
# ---------------------------------------------------------------------------

def _resolve_width(size: str | None, width: int | None, cap: int) -> int:
    """Resolve an explicit width, a named size preset, or fall back to
    the terminal's current width (capped at `cap`)."""
    if width:
        return width
    if size:
        key = size.lower()
        if key not in SIZE_PRESETS:
            raise ClidevError(
                f"Unknown size '{size}'. Choose from: {list(SIZE_PRESETS)}, "
                "or pass an explicit width=<int>."
            )
        return SIZE_PRESETS[key]
    terminal_width = shutil.get_terminal_size(fallback=(80, 24)).columns
    return min(terminal_width, cap)


def _is_url(source: str) -> bool:
    return source.startswith("http://") or source.startswith("https://")


def _is_google_drive(url: str) -> bool:
    host = urlparse(url).netloc
    return any(host.endswith(g) for g in _GDRIVE_HOSTS)


def _extract_gdrive_file_id(url: str) -> str | None:
    # Handles both /file/d/<id>/view and ?id=<id> style Drive links.
    match = re.search(r"/d/([a-zA-Z0-9_-]+)", url)
    if match:
        return match.group(1)
    query_id = parse_qs(urlparse(url).query).get("id")
    return query_id[0] if query_id else None


def _download_google_drive(url: str, dest_path: str):
    """Download a Google Drive file, handling the 'file too large to scan
    for viruses, download anyway?' confirmation token Drive adds for big files."""
    if requests is None:
        raise ClidevError(
            "The 'requests' package is required to load from Google Drive. "
            "Install it with: pip install requests"
        )

    file_id = _extract_gdrive_file_id(url)
    if not file_id:
        raise ClidevError(f"Could not extract a file ID from Google Drive URL: {url}")

    session = requests.Session()
    base_url = "https://drive.google.com/uc?export=download"

    response = session.get(base_url, params={"id": file_id}, stream=True)
    token = next(
        (v for k, v in response.cookies.items() if k.startswith("download_warning")),
        None,
    )
    if token:
        response = session.get(
            base_url, params={"id": file_id, "confirm": token}, stream=True
        )

    if response.status_code != 200:
        raise ClidevError(f"Failed to download from Google Drive (status {response.status_code}).")

    with open(dest_path, "wb") as f:
        for chunk in response.iter_content(chunk_size=1024 * 256):
            if chunk:
                f.write(chunk)


def _download_url(url: str, dest_path: str):
    if requests is None:
        raise ClidevError(
            "The 'requests' package is required to load images/video from a URL. "
            "Install it with: pip install requests"
        )
    response = requests.get(url, stream=True, timeout=30)
    if response.status_code != 200:
        raise ClidevError(f"Failed to download '{url}' (status {response.status_code}).")
    with open(dest_path, "wb") as f:
        for chunk in response.iter_content(chunk_size=1024 * 256):
            if chunk:
                f.write(chunk)


def _guess_suffix(url: str, default: str) -> str:
    path = urlparse(url).path
    suffix = Path(path).suffix
    return suffix if suffix else default


def resolve_source(source: str, default_suffix: str) -> tuple[str, bool]:
    """Resolve a local path, direct URL, or Google Drive link into a local
    file path ready to open. Returns (local_path, is_temp_file).

    Downloaded files are written to a temp file the caller is responsible
    for cleaning up (via cleanup_temp_file) once done with them.
    """
    if not _is_url(source):
        return source, False

    suffix = _guess_suffix(source, default_suffix)
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    tmp.close()

    if _is_google_drive(source):
        _download_google_drive(source, tmp.name)
    else:
        _download_url(source, tmp.name)

    return tmp.name, True


def cleanup_temp_file(path: str, is_temp: bool):
    if is_temp:
        try:
            Path(path).unlink(missing_ok=True)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Images
# ---------------------------------------------------------------------------

class TerminalImage:
    """Render a static image as colored terminal blocks.

    app.image("photo.png").show()
    app.image("photo.png", size="large").show()
    app.image("https://example.com/photo.png").show()
    app.image("https://drive.google.com/file/d/FILE_ID/view").show()
    """

    def __init__(self, path: str, size: str | None = "medium", width: int | None = None,
                 console: Console | None = None):
        """
        Args:
            path: Local file path, direct URL, or Google Drive share link.
            size: One of "small" (40 cols), "medium" (80 cols), "large"
                  (120 cols). Ignored if `width` is given.
            width: Explicit width in terminal columns. Overrides `size`.
            console: Optional rich Console to print to.
        """
        if PILImage is None:
            raise ClidevError(
                "Pillow is required to render images. Install it with: pip install Pillow"
            )
        self.path = path
        self.size = size
        self.width = width
        self._console = console or Console()
        self._local_path, self._is_temp = resolve_source(path, default_suffix=".png")

    def _target_width(self) -> int:
        return _resolve_width(self.size, self.width, cap=120)

    def _load_pixels(self):
        img = PILImage.open(self._local_path).convert("RGB")
        target_width = self._target_width()
        aspect_ratio = img.height / img.width
        target_height = max(2, int(target_width * aspect_ratio * 0.5) * 2)
        return img.resize((target_width, target_height))

    def render(self) -> str:
        img = self._load_pixels()
        width, height = img.size
        pixels = img.load()
        lines = []
        for y in range(0, height - 1, 2):
            parts = []
            for x in range(width):
                tr, tg, tb = pixels[x, y]
                br, bg, bb = pixels[x, y + 1]
                parts.append(
                    f"[rgb({tr},{tg},{tb}) on rgb({br},{bg},{bb})]{_UPPER_HALF_BLOCK}[/]"
                )
            lines.append("".join(parts))
        return "\n".join(lines)

    def show(self):
        self._console.print(self.render())

    def cleanup(self):
        """Delete the downloaded temp file, if this image came from a URL."""
        cleanup_temp_file(self._local_path, self._is_temp)

    def __del__(self):
        try:
            self.cleanup()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Video (silent -- no audio)
# ---------------------------------------------------------------------------

class TerminalVideo:
    """Play a video inline in the terminal as a sequence of colored-block
    frames (visual only, no audio).

    app.video("clip.mp4").play()                          # 24 fps by default
    app.video("clip.mp4", size="small").play()             # smaller = faster to render
    app.video("https://example.com/clip.mp4").play()
    app.video("https://drive.google.com/file/d/FILE_ID/view").play()

    Frame timing is measured with a monotonic clock and accounts for how
    long each frame actually took to render, so playback stays close to
    the target fps instead of drifting slower the longer it plays.
    """

    def __init__(self, path: str, size: str | None = "medium", width: int | None = None,
                 fps: float | None = None, console: Console | None = None):
        """
        Args:
            path: Local file path, direct URL, or Google Drive share link.
            size: One of "small" (40 cols), "medium" (80 cols), "large"
                  (100 cols). Ignored if `width` is given.
            width: Explicit width in terminal columns. Overrides `size`.
            fps: Target playback frame rate. Defaults to 24.
            console: Optional rich Console to print to.
        """
        if cv2 is None:
            raise ClidevError(
                "opencv-python is required to render video. "
                "Install it with: pip install opencv-python"
            )

        self.path = path
        self.size = size
        self.width = width
        self.fps_override = fps
        self._console = console or Console()
        self.source_fps: float | None = None

        self._local_path, self._is_temp = resolve_source(path, default_suffix=".mp4")

    def _target_width(self) -> int:
        return _resolve_width(self.size, self.width, cap=100)

    def _frame_to_text(self, frame) -> str:
        height_px, width_px = frame.shape[:2]
        target_width = self._target_width()
        aspect_ratio = height_px / width_px
        target_height = max(2, int(target_width * aspect_ratio * 0.5) * 2)

        frame = cv2.resize(frame, (target_width, target_height))
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        lines = []
        for y in range(0, frame.shape[0] - 1, 2):
            parts = []
            for x in range(frame.shape[1]):
                tr, tg, tb = frame[y, x]
                br, bg, bb = frame[y + 1, x]
                parts.append(
                    f"[rgb({tr},{tg},{tb}) on rgb({br},{bg},{bb})]{_UPPER_HALF_BLOCK}[/]"
                )
            lines.append("".join(parts))
        return "\n".join(lines)

    def play(self, max_frames: int | None = None, skip: int = 1):
        """Play the video.

        Args:
            max_frames: stop after this many rendered frames (None = whole video).
            skip: render every Nth source frame. Increase this if the source
                  video's native fps is much higher than your target fps.
        """
        capture = cv2.VideoCapture(self._local_path)
        if not capture.isOpened():
            raise ClidevError(f"Could not open video: {self.path}")

        self.source_fps = capture.get(cv2.CAP_PROP_FPS) or _DEFAULT_FPS
        target_fps = self.fps_override or _DEFAULT_FPS
        frame_interval = 1 / target_fps

        frame_index = 0
        rendered = 0
        next_frame_time = time.perf_counter()

        try:
            with self._console.screen():
                while True:
                    ok, frame = capture.read()
                    if not ok:
                        break

                    if frame_index % skip == 0:
                        rendered_text = self._frame_to_text(frame)

                        now = time.perf_counter()
                        sleep_for = next_frame_time - now
                        if sleep_for > 0:
                            time.sleep(sleep_for)

                        self._console.print(rendered_text)
                        rendered += 1
                        next_frame_time += frame_interval

                        if max_frames and rendered >= max_frames:
                            break

                    frame_index += 1
        finally:
            capture.release()
            self.cleanup()

    def cleanup(self):
        """Delete the downloaded temp video file, if this came from a URL."""
        cleanup_temp_file(self._local_path, self._is_temp)

    def __del__(self):
        try:
            self.cleanup()
        except Exception:
            pass