"""Cross-platform shell / subprocess execution: app.cmd(...)."""

import subprocess
import threading
from dataclasses import dataclass

from .exceptions import CommandError


@dataclass
class CommandResult:
    command: str
    returncode: int
    stdout: str = ""
    stderr: str = ""

    @property
    def ok(self) -> bool:
        return self.returncode == 0


class BackgroundHandle:
    """Handle returned for background=True commands."""

    def __init__(self, thread: threading.Thread, popen: subprocess.Popen):
        self._thread = thread
        self.popen = popen

    def is_running(self) -> bool:
        return self.popen.poll() is None

    def wait(self) -> CommandResult:
        stdout, stderr = self.popen.communicate()
        self._thread.join()
        return CommandResult(
            command=" ".join(self.popen.args) if isinstance(self.popen.args, list) else str(self.popen.args),
            returncode=self.popen.returncode,
            stdout=stdout or "",
            stderr=stderr or "",
        )

    def terminate(self):
        self.popen.terminate()


class Shell:
    """Facade exposed as app.cmd via a thin wrapper in App, or used directly."""

    def run(self, command: str, capture: bool = False, background: bool = False,
             check: bool = False, shell: bool = True, cwd: str | None = None):
        if background:
            popen = subprocess.Popen(
                command,
                shell=shell,
                cwd=cwd,
                stdout=subprocess.PIPE if capture else None,
                stderr=subprocess.PIPE if capture else None,
                text=True,
            )
            thread = threading.Thread(target=popen.wait, daemon=True)
            thread.start()
            return BackgroundHandle(thread, popen)

        result = subprocess.run(
            command,
            shell=shell,
            cwd=cwd,
            capture_output=capture,
            text=True,
        )
        cmd_result = CommandResult(
            command=command,
            returncode=result.returncode,
            stdout=result.stdout or "" if capture else "",
            stderr=result.stderr or "" if capture else "",
        )
        if check and not cmd_result.ok:
            raise CommandError(
                f"Command '{command}' exited with code {cmd_result.returncode}",
                returncode=cmd_result.returncode,
                stdout=cmd_result.stdout,
                stderr=cmd_result.stderr,
            )
        return cmd_result
