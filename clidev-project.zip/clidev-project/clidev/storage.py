"""Pluggable data storage backends: memory, JSON, SQLite, YAML, TOML."""

import json
import sqlite3
from abc import ABC, abstractmethod
from pathlib import Path

from .exceptions import StorageError

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

try:
    import toml
except ImportError:  # pragma: no cover
    toml = None


class StorageBackend(ABC):
    @abstractmethod
    def save(self, name: str, data): ...

    @abstractmethod
    def load(self, name: str): ...

    @abstractmethod
    def delete(self, name: str): ...

    @abstractmethod
    def all(self) -> dict: ...


class MemoryStorage(StorageBackend):
    """Volatile, in-process storage. Data is lost when the app exits."""

    def __init__(self):
        self._data = {}

    def save(self, name, data):
        self._data[name] = data

    def load(self, name):
        return self._data.get(name)

    def delete(self, name):
        self._data.pop(name, None)

    def all(self):
        return dict(self._data)


class JSONStorage(StorageBackend):
    """Persists all records to a single JSON file."""

    def __init__(self, path: str = ".clidev_storage.json"):
        self.path = Path(path)
        if not self.path.exists():
            self.path.write_text("{}")

    def _read(self):
        try:
            return json.loads(self.path.read_text() or "{}")
        except json.JSONDecodeError as e:
            raise StorageError(f"Corrupt JSON storage file: {e}") from e

    def _write(self, data):
        self.path.write_text(json.dumps(data, indent=2, default=str))

    def save(self, name, data):
        all_data = self._read()
        all_data[name] = data
        self._write(all_data)

    def load(self, name):
        return self._read().get(name)

    def delete(self, name):
        data = self._read()
        data.pop(name, None)
        self._write(data)

    def all(self):
        return self._read()


class YAMLStorage(StorageBackend):
    def __init__(self, path: str = ".clidev_storage.yaml"):
        if yaml is None:
            raise StorageError("PyYAML is required for YAMLStorage. pip install pyyaml")
        self.path = Path(path)
        if not self.path.exists():
            self.path.write_text("{}")

    def _read(self):
        return yaml.safe_load(self.path.read_text()) or {}

    def _write(self, data):
        self.path.write_text(yaml.safe_dump(data))

    def save(self, name, data):
        all_data = self._read()
        all_data[name] = data
        self._write(all_data)

    def load(self, name):
        return self._read().get(name)

    def delete(self, name):
        data = self._read()
        data.pop(name, None)
        self._write(data)

    def all(self):
        return self._read()


class TOMLStorage(StorageBackend):
    def __init__(self, path: str = ".clidev_storage.toml"):
        if toml is None:
            raise StorageError("toml is required for TOMLStorage. pip install toml")
        self.path = Path(path)
        if not self.path.exists():
            self.path.write_text("")

    def _read(self):
        content = self.path.read_text()
        return toml.loads(content) if content.strip() else {}

    def _write(self, data):
        self.path.write_text(toml.dumps(data))

    def save(self, name, data):
        all_data = self._read()
        all_data[name] = data
        self._write(all_data)

    def load(self, name):
        return self._read().get(name)

    def delete(self, name):
        data = self._read()
        data.pop(name, None)
        self._write(data)

    def all(self):
        return self._read()


class SQLiteStorage(StorageBackend):
    """Key-value storage backed by SQLite (values stored as JSON text)."""

    def __init__(self, path: str = ".clidev_storage.db"):
        self.path = path
        self._conn = sqlite3.connect(self.path)
        self._conn.execute(
            "CREATE TABLE IF NOT EXISTS clidev_kv (name TEXT PRIMARY KEY, value TEXT)"
        )
        self._conn.commit()

    def save(self, name, data):
        self._conn.execute(
            "INSERT INTO clidev_kv (name, value) VALUES (?, ?) "
            "ON CONFLICT(name) DO UPDATE SET value=excluded.value",
            (name, json.dumps(data, default=str)),
        )
        self._conn.commit()

    def load(self, name):
        row = self._conn.execute(
            "SELECT value FROM clidev_kv WHERE name = ?", (name,)
        ).fetchone()
        return json.loads(row[0]) if row else None

    def delete(self, name):
        self._conn.execute("DELETE FROM clidev_kv WHERE name = ?", (name,))
        self._conn.commit()

    def all(self):
        rows = self._conn.execute("SELECT name, value FROM clidev_kv").fetchall()
        return {name: json.loads(value) for name, value in rows}

    def close(self):
        self._conn.close()


BACKENDS = {
    "memory": MemoryStorage,
    "json": JSONStorage,
    "sqlite": SQLiteStorage,
    "yaml": YAMLStorage,
    "toml": TOMLStorage,
}


class Storage:
    """Facade exposed as app.storage, e.g. app.storage.save("user", data)."""

    def __init__(self, backend: str | StorageBackend = "memory", **kwargs):
        if isinstance(backend, StorageBackend):
            self._backend = backend
        else:
            if backend not in BACKENDS:
                raise StorageError(
                    f"Unknown storage backend '{backend}'. Options: {list(BACKENDS)}"
                )
            self._backend = BACKENDS[backend](**kwargs)

    def save(self, name: str, data):
        self._backend.save(name, data)

    def load(self, name: str, default=None):
        value = self._backend.load(name)
        return value if value is not None else default

    def delete(self, name: str):
        self._backend.delete(name)

    def all(self) -> dict:
        return self._backend.all()
