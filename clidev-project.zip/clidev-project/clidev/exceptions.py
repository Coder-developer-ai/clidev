"""Custom exceptions used across clidev."""


class ClidevError(Exception):
    """Base exception for all clidev errors."""


class NavigationError(ClidevError):
    """Raised when navigation (goto/back) fails, e.g. unknown page."""


class ValidationError(ClidevError):
    """Raised when a form field fails validation."""


class StorageError(ClidevError):
    """Raised when a storage backend operation fails."""


class WorkflowError(ClidevError):
    """Raised when a workflow step fails or is misconfigured."""


class PluginError(ClidevError):
    """Raised when a plugin fails to load or run."""


class CommandError(ClidevError):
    """Raised when a shell command fails (non-zero exit) and check=True."""

    def __init__(self, message, returncode=None, stdout=None, stderr=None):
        super().__init__(message)
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr
