"""Dialog helpers: confirm / prompt / alert boxes."""

import questionary
from rich.console import Console
from rich.panel import Panel


class Dialog:
    def __init__(self, theme=None):
        self.theme = theme
        self._console = Console()

    def confirm(self, message: str, default: bool = True) -> bool:
        return questionary.confirm(message, default=default).ask()

    def prompt(self, message: str, default: str = "") -> str:
        return questionary.text(message, default=default).ask()

    def alert(self, message: str, title: str = "Alert"):
        color = self.theme.get("warning") if self.theme else "yellow"
        self._console.print(Panel(message, title=title, border_style=color, expand=False))

    def confirm_exit(self, message: str = "Are you sure you want to exit?") -> bool:
        return self.confirm(message, default=False)
