"""Task registry: @app.task decorator + app.run_task(name)."""

from .exceptions import ClidevError


class TaskRegistry:
    def __init__(self):
        self._tasks: dict[str, callable] = {}

    def register(self, fn=None, *, name: str | None = None):
        """Use as @app.task or @app.task(name="custom_name")."""
        if fn is not None and callable(fn):
            self._tasks[name or fn.__name__] = fn
            return fn

        def decorator(f):
            self._tasks[name or f.__name__] = f
            return f

        return decorator

    def run(self, name: str, *args, **kwargs):
        if name not in self._tasks:
            raise ClidevError(f"No task named '{name}' has been registered.")
        return self._tasks[name](*args, **kwargs)

    def names(self):
        return list(self._tasks.keys())
