"""Color name constants and helpers, mapped to rich-compatible color strings."""

PALETTE = {
    "blue": "#3B82F6",
    "green": "#22C55E",
    "red": "#EF4444",
    "yellow": "#EAB308",
    "orange": "#F97316",
    "purple": "#A855F7",
    "cyan": "#06B6D4",
    "magenta": "#D946EF",
    "white": "#FFFFFF",
    "black": "#000000",
    "gray": "#6B7280",
    "grey": "#6B7280",
}


def resolve(color: str) -> str:
    """Resolve a friendly color name to a rich-compatible color string.

    If the color isn't in the palette, it's passed through unchanged
    (so hex codes and rich color names still work).
    """
    if not color:
        return color
    return PALETTE.get(color.lower(), color)
