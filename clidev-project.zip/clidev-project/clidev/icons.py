"""Small set of unicode icons used throughout clidev's UI output."""

ICONS = {
    "success": "\u2713",   # check mark
    "error": "\u2717",     # cross mark
    "warning": "\u26A0",   # warning sign
    "info": "\u2139",      # info
    "arrow": "\u2192",     # right arrow
    "bullet": "\u2022",
    "star": "\u2605",
    "spinner": "\u25CF",
}


def icon(name: str, default: str = "") -> str:
    return ICONS.get(name, default)
