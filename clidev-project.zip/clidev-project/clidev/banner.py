"""Render text as large ASCII-art banners made of symbols.

Usage:
    app.banner("HI").show()
    app.banner("HI", symbol="@").show()

Or standalone:
    from clidev.banner import Banner
    Banner("HELLO", symbol="*").show()
"""

from rich.console import Console

# Each glyph is a list of 5 rows, all rows the same width.
# '#' = filled pixel, '.' = empty pixel.
_FONT: dict[str, list[str]] = {
    "A": [".###.", "#...#", "#####", "#...#", "#...#"],
    "B": ["####.", "#...#", "####.", "#...#", "####."],
    "C": [".####", "#....", "#....", "#....", ".####"],
    "D": ["###..", "#..#.", "#...#", "#..#.", "###.."],
    "E": ["#####", "#....", "###..", "#....", "#####"],
    "F": ["#####", "#....", "###..", "#....", "#...."],
    "G": [".####", "#....", "#..##", "#...#", ".####"],
    "H": ["#...#", "#...#", "#####", "#...#", "#...#"],
    "I": ["#####", "..#..", "..#..", "..#..", "#####"],
    "J": ["...##", "....#", "....#", "#...#", ".###."],
    "K": ["#..#.", "#.#..", "##...", "#.#..", "#..#."],
    "L": ["#....", "#....", "#....", "#....", "#####"],
    "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#"],
    "N": ["#...#", "##..#", "#.#.#", "#..##", "#...#"],
    "O": [".###.", "#...#", "#...#", "#...#", ".###."],
    "P": ["####.", "#...#", "####.", "#....", "#...."],
    "Q": [".###.", "#...#", "#...#", "#..#.", ".##.#"],
    "R": ["####.", "#...#", "####.", "#.#..", "#..#."],
    "S": [".####", "#....", ".###.", "....#", "####."],
    "T": ["#####", "..#..", "..#..", "..#..", "..#.."],
    "U": ["#...#", "#...#", "#...#", "#...#", ".###."],
    "V": ["#...#", "#...#", "#...#", ".#.#.", "..#.."],
    "W": ["#...#", "#...#", "#.#.#", "##.##", "#...#"],
    "X": ["#...#", ".#.#.", "..#..", ".#.#.", "#...#"],
    "Y": ["#...#", ".#.#.", "..#..", "..#..", "..#.."],
    "Z": ["#####", "...#.", "..#..", ".#...", "#####"],
    "0": [".###.", "#...#", "#...#", "#...#", ".###."],
    "1": ["..#..", ".##..", "..#..", "..#..", ".###."],
    "2": [".###.", "#...#", "..##.", ".#...", "#####"],
    "3": ["####.", "...#.", "..##.", "...#.", "####."],
    "4": ["#..#.", "#..#.", "#####", "...#.", "...#."],
    "5": ["#####", "#....", "####.", "....#", "####."],
    "6": [".###.", "#....", "####.", "#...#", ".###."],
    "7": ["#####", "...#.", "..#..", ".#...", "#...."],
    "8": [".###.", "#...#", ".###.", "#...#", ".###."],
    "9": [".###.", "#...#", ".####", "....#", ".###."],
    " ": [".....", ".....", ".....", ".....", "....."],
    "!": ["..#..", "..#..", "..#..", ".....", "..#.."],
    "?": [".###.", "#...#", "..##.", ".....", "..#.."],
    ".": [".....", ".....", ".....", ".....", "..#.."],
    ",": [".....", ".....", ".....", "..#..", ".#..."],
    "-": [".....", ".....", "#####", ".....", "....."],
    ":": [".....", "..#..", ".....", "..#..", "....."],
}

_GLYPH_HEIGHT = 5
_UNKNOWN_CHAR = " "


class Banner:
    """Render text as a large ASCII-art banner made of a chosen symbol.

    Each character is looked up in a 5-row block font, then every filled
    pixel ('#') in that glyph is replaced with `symbol`. Unsupported
    characters fall back to a blank glyph (a space).

    Example:
        Banner("HI", symbol="@").show()

        @@@@   @   @
        @  @   @   @
        @@@@   @@@@@
        @  @   @   @
        @  @   @   @
    """

    def __init__(self, text: str = "", symbol: str = "#", theme=None,
                 spacing: int = 1, console: Console | None = None):
        """
        Args:
            text: The text to render. Case-insensitive (rendered as uppercase).
            symbol: The single character used to draw filled pixels.
            theme: Optional Theme instance; if provided, uses theme["primary"]
                   as the banner's display color.
            spacing: Number of blank columns between letters.
            console: Optional rich Console to print to.
        """
        self.text = text.upper()
        self.symbol = symbol or "#"
        self.theme = theme
        self.spacing = max(0, spacing)
        self._console = console or Console()

    def _glyph_for(self, char: str) -> list[str]:
        return _FONT.get(char, _FONT[_UNKNOWN_CHAR])

    def render(self) -> str:
        """Build and return the multi-line banner string (without styling)."""
        if not self.text:
            return ""

        gap = " " * self.spacing
        rows = ["" for _ in range(_GLYPH_HEIGHT)]

        for char in self.text:
            glyph = self._glyph_for(char)
            for row_index in range(_GLYPH_HEIGHT):
                pixel_row = glyph[row_index].replace("#", self.symbol).replace(".", " ")
                rows[row_index] += pixel_row + gap

        return "\n".join(row.rstrip() for row in rows)

    def show(self):
        """Print the rendered banner to the console, using theme color if set."""
        output = self.render()
        if not output:
            return
        color = self.theme.get("primary") if self.theme else None
        style = f"bold {color}" if color else "bold"
        self._console.print(f"[{style}]{output}[/{style}]")

    def __str__(self):
        return self.render()

    def __repr__(self):
        return f"Banner(text={self.text!r}, symbol={self.symbol!r})"