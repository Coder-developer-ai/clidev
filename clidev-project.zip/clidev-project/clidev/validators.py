"""Built-in field validators used by forms.py / inputs.py."""

import re
from datetime import datetime

from .exceptions import ValidationError

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
URL_RE = re.compile(r"^(https?|ftp)://[^\s/$.?#].[^\s]*$", re.IGNORECASE)


def required(value):
    if value is None or (isinstance(value, str) and value.strip() == ""):
        raise ValidationError("This field is required.")
    return value


def is_email(value):
    if value and not EMAIL_RE.match(value):
        raise ValidationError("Enter a valid email address.")
    return value


def is_url(value):
    if value and not URL_RE.match(value):
        raise ValidationError("Enter a valid URL.")
    return value


def is_number(value):
    try:
        if isinstance(value, (int, float)):
            return value
        return float(value) if "." in str(value) else int(value)
    except (ValueError, TypeError) as e:
        raise ValidationError("Enter a valid number.") from e


def min_length(n):
    def _validator(value):
        if value is not None and len(str(value)) < n:
            raise ValidationError(f"Must be at least {n} characters.")
        return value

    return _validator


def max_length(n):
    def _validator(value):
        if value is not None and len(str(value)) > n:
            raise ValidationError(f"Must be at most {n} characters.")
        return value

    return _validator


def min_value(n):
    def _validator(value):
        if value is not None and float(value) < n:
            raise ValidationError(f"Must be at least {n}.")
        return value

    return _validator


def max_value(n):
    def _validator(value):
        if value is not None and float(value) > n:
            raise ValidationError(f"Must be at most {n}.")
        return value

    return _validator


def is_date(fmt="%Y-%m-%d"):
    def _validator(value):
        try:
            datetime.strptime(str(value), fmt)
        except ValueError as e:
            raise ValidationError(f"Enter a valid date ({fmt}).") from e
        return value

    return _validator


def run_validators(value, validators):
    """Run a list of validator callables against value, raising on first failure."""
    for validator in validators:
        value = validator(value)
    return value
