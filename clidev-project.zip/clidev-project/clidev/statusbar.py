"""A simple single-line status bar rendered at the bottom of output."""

from rich.console import Console


class StatusBar:
    def __init__(self, theme=None, console: Console | None = None):
        self.theme = theme
        self.console = console or Console()
        self._segments: list[str] = []

    def set(self, *segments: str) -> "StatusBar":
        self._segments = list(segments)
        return self

    def render(self):
        color = self.theme.get("muted") if self.theme else None
        style = color or "dim"
        line = "  |  ".join(self._segments)
        self.console.print(f"[{style}]{line}[/{style}]")
