"""Built-in reusable pieces (sample plugins, sample themes) shipped with clidev."""
