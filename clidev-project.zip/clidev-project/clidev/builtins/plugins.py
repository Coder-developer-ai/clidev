"""A couple of small example plugins shipped with clidev for reference."""

from ..plugins import Plugin


class GitPlugin(Plugin):
    """Adds basic git-awareness to an app: checks if the cwd is a repo."""

    name = "git"

    def on_install(self, app):
        result = app.cmd("git rev-parse --is-inside-work-tree", capture=True)
        app.state["git_repo"] = result.ok

    def on_start(self, app):
        if app.state.get("git_repo"):
            app.logger.debug("Git repository detected.")


class DatabasePlugin(Plugin):
    """Example plugin that ensures a storage backend is ready on start."""

    name = "database"

    def on_start(self, app):
        app.logger.debug(f"Storage backend ready: {app.storage.all().keys()}")
