"""Simple indeterminate spinner context manager: with app.spinner("Loading"): ..."""

from rich.console import Console
from rich.status import Status


class Spinner:
    def __init__(self, label: str = "Loading...", console: Console | None = None):
        self.label = label
        self.console = console or Console()
        self._status: Status | None = None

    def __enter__(self):
        self._status = self.console.status(self.label)
        self._status.start()
        return self

    def update(self, text: str):
        if self._status is not None:
            self._status.update(text)

    def __exit__(self, exc_type, exc, tb):
        if self._status is not None:
            self._status.stop()
        return False
