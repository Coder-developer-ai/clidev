"""Event dispatcher powering @app.on_start / on_exit / on_submit / on_error."""

from collections import defaultdict


class EventDispatcher:
    """A minimal pub/sub dispatcher.

    Named events: "start", "exit", "error" plus per-form "submit:<form_id>".
    """

    def __init__(self):
        self._handlers = defaultdict(list)

    def on(self, event: str, handler=None):
        """Register a handler for `event`. Can be used as a decorator too."""
        if handler is not None:
            self._handlers[event].append(handler)
            return handler

        def decorator(fn):
            self._handlers[event].append(fn)
            return fn

        return decorator

    def off(self, event: str, handler):
        if handler in self._handlers[event]:
            self._handlers[event].remove(handler)

    def emit(self, event: str, *args, **kwargs):
        """Call every handler registered for `event`, returning their results."""
        results = []
        for handler in self._handlers.get(event, []):
            results.append(handler(*args, **kwargs))
        return results

    def has(self, event: str) -> bool:
        return bool(self._handlers.get(event))
