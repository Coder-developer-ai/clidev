"""Card widget: a titled panel of content, wraps rich.panel.Panel."""

from rich.console import Console
from rich.panel import Panel


class Card:
    def __init__(self, title: str, content: str = "", theme=None):
        self.title = title
        self.content = content
        self.theme = theme
        self._console = Console()

    def show(self):
        color = self.theme.get("primary") if self.theme else None
        border_style = color or "white"
        self._console.print(
            Panel(self.content, title=self.title, border_style=border_style, expand=False)
        )
