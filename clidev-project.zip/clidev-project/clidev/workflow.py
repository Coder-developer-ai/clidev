"""Sequential step-based workflow engine."""

from .exceptions import WorkflowError


class Workflow:
    """A sequence of steps run in order, sharing a context dict between them.

    workflow = app.workflow()
    workflow.step(login)
    workflow.step(select_project)
    workflow.step(build)
    workflow.step(deploy)
    workflow.start()

    Each step function may optionally accept a single `context` dict argument;
    its return value (if a dict) is merged into the shared context for
    subsequent steps.
    """

    def __init__(self, app=None, name: str = "workflow"):
        self.app = app
        self.name = name
        self.steps: list = []
        self.context: dict = {}

    def step(self, fn) -> "Workflow":
        self.steps.append(fn)
        return self

    def start(self, initial_context: dict | None = None):
        self.context = dict(initial_context or {})
        for i, fn in enumerate(self.steps):
            try:
                result = self._call_step(fn)
            except Exception as e:
                if self.app is not None:
                    self.app.events.emit("error", e)
                raise WorkflowError(
                    f"Workflow '{self.name}' failed at step {i} ({getattr(fn, '__name__', fn)}): {e}"
                ) from e
            if isinstance(result, dict):
                self.context.update(result)
        return self.context

    def _call_step(self, fn):
        import inspect

        sig = inspect.signature(fn)
        if len(sig.parameters) >= 1:
            return fn(self.context)
        return fn()
