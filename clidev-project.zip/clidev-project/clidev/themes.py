"""Theming support for clidev applications."""

from .colors import resolve


class Theme:
    """A mutable theme object.

    Usage:
        theme = Theme()
        theme.primary("blue")
        theme.success("green")

    Or start from a built-in preset:
        theme = Theme.preset("dark")
    """

    _DEFAULTS = {
        "primary": "cyan",
        "secondary": "blue",
        "success": "green",
        "warning": "yellow",
        "error": "red",
        "info": "cyan",
        "text": "white",
        "muted": "gray",
        "background": "black",
        "accent": "magenta",
    }

    def __init__(self):
        self._colors = dict(self._DEFAULTS)

    # --- fluent setters -------------------------------------------------
    def _set(self, key, color):
        self._colors[key] = resolve(color)
        return self

    def primary(self, color):
        return self._set("primary", color)

    def secondary(self, color):
        return self._set("secondary", color)

    def success(self, color):
        return self._set("success", color)

    def warning(self, color):
        return self._set("warning", color)

    def error(self, color):
        return self._set("error", color)

    def info(self, color):
        return self._set("info", color)

    def text(self, color):
        return self._set("text", color)

    def muted(self, color):
        return self._set("muted", color)

    def background(self, color):
        return self._set("background", color)

    def accent(self, color):
        return self._set("accent", color)

    # --- access -----------------------------------------------------------
    def get(self, key, fallback=None):
        return self._colors.get(key, fallback)

    def __getitem__(self, key):
        return self._colors[key]

    def as_dict(self):
        return dict(self._colors)

    @classmethod
    def preset(cls, name: str) -> "Theme":
        theme = cls()
        if name == "dark":
            theme.primary("cyan").secondary("blue").success("green")
            theme.warning("yellow").error("red").text("white")
            theme.muted("gray").background("black").accent("magenta")
        elif name == "light":
            theme.primary("blue").secondary("purple").success("green")
            theme.warning("orange").error("red").text("black")
            theme.muted("gray").background("white").accent("magenta")
        else:
            # Unknown theme name -> defaults
            pass
        return theme

    def __repr__(self):
        return f"Theme({self._colors})"
