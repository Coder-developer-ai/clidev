"""Themed logger used as app.logger."""

import datetime as _dt

from rich.console import Console


class Logger:
    """Simple themed logger.

    app.logger.info("Started")
    app.logger.warning("Careful")
    app.logger.error("Failed")
    """

    def __init__(self, theme=None, console: Console | None = None, timestamps: bool = True):
        self.theme = theme
        self.console = console or Console()
        self.timestamps = timestamps
        self._history = []

    def _ts(self):
        return _dt.datetime.now().strftime("%H:%M:%S")

    def _emit(self, level, style_key, symbol, message):
        color = self.theme.get(style_key) if self.theme else None
        prefix = f"[dim]{self._ts()}[/dim] " if self.timestamps else ""
        style = f"bold {color}" if color else "bold"
        line = f"{prefix}[{style}]{symbol} {level.upper()}[/{style}] {message}"
        self._history.append((level, message))
        self.console.print(line)

    def info(self, message):
        self._emit("info", "info", "\u2139", message)

    def success(self, message):
        self._emit("success", "success", "\u2713", message)

    def warning(self, message):
        self._emit("warning", "warning", "\u26A0", message)

    def error(self, message):
        self._emit("error", "error", "\u2717", message)

    def debug(self, message):
        self._emit("debug", "muted", "\u2022", message)

    @property
    def history(self):
        return list(self._history)
