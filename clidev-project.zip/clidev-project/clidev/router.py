"""Navigation: app.goto(name), app.back(), history stack."""

from .exceptions import NavigationError
from .pages import PageRegistry


class Router:
    def __init__(self, app=None):
        self.app = app
        self.pages = PageRegistry()
        self.history: list[str] = []
        self.current: str | None = None

    def page(self, name: str, handler=None):
        return self.pages.register(name, handler)

    def goto(self, name: str, *args, **kwargs):
        page = self.pages.get(name)
        if page is None:
            raise NavigationError(f"No page named '{name}' has been registered.")
        if self.current is not None:
            self.history.append(self.current)
        self.current = name
        return page.render(*args, **kwargs)

    def back(self):
        if not self.history:
            raise NavigationError("No previous page to go back to.")
        previous = self.history.pop()
        page = self.pages.get(previous)
        self.current = previous
        if page is not None:
            return page.render()

    def reset(self):
        self.history.clear()
        self.current = None
