"""Small shared utility helpers."""

import re


def slugify(text: str) -> str:
    text = text.strip().lower()
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_")


def truncate(text: str, length: int = 40) -> str:
    return text if len(text) <= length else text[: length - 1] + "\u2026"


def merge_dicts(*dicts: dict) -> dict:
    result = {}
    for d in dicts:
        result.update(d)
    return result
