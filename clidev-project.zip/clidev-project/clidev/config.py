"""Simple application configuration container."""


class Config:
    """Holds app-level configuration with attribute and dict-style access."""

    def __init__(self, **kwargs):
        self._data = {
            "theme": "dark",
            "storage_backend": "memory",
            "storage_path": None,
            "log_timestamps": True,
            "confirm_exit": False,
        }
        self._data.update(kwargs)

    def __getattr__(self, key):
        try:
            return self._data[key]
        except KeyError as e:
            raise AttributeError(key) from e

    def __setattr__(self, key, value):
        if key == "_data":
            super().__setattr__(key, value)
        else:
            self._data[key] = value

    def __getitem__(self, key):
        return self._data[key]

    def __setitem__(self, key, value):
        self._data[key] = value

    def as_dict(self):
        return dict(self._data)
