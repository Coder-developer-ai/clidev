"""Helper to scaffold a new form snippet."""

FORM_SNIPPET = '''
{var_name} = app.form("{title}")
{var_name}.text("Name")
'''


def generate_form_snippet(title: str) -> str:
    var_name = title.lower().replace(" ", "_")
    return FORM_SNIPPET.format(var_name=var_name, title=title)
