"""Scaffolds a new clidev project: `clidev new myproject`."""

from pathlib import Path

APP_PY = '''"""Main application entry point for {project_name}."""

from clidev import App

from routes import register_routes
from menus import build_menus

app = App("{title}")

register_routes(app)
build_menus(app)

if __name__ == "__main__":
    app.run()
'''

ROUTES_PY = '''"""Page routes for {project_name}."""


def register_routes(app):
    @app.page("home")
    def home():
        app.info("Welcome to {title}!")
'''

MENUS_PY = '''"""Menu definitions for {project_name}."""


def build_menus(app):
    main = app.menu("Main Menu")
    main.option("Say Hello", lambda: app.success("Hello from {title}!"))
    main.option("Exit", app.exit)
    return main
'''

FORMS_PY = '''"""Form definitions for {project_name}."""


def build_forms(app):
    form = app.form("Example")
    form.text("Name")
    form.email("Email")
    return form
'''

WORKFLOWS_PY = '''"""Workflow definitions for {project_name}."""


def build_workflows(app):
    workflow = app.workflow("example")

    def step_one(context):
        app.info("Step one running...")
        return {{"step_one_done": True}}

    workflow.step(step_one)
    return workflow
'''

COMMANDS_PY = '''"""Shell command helpers for {project_name}."""


def setup_environment(app):
    app.cmd("python -m venv .venv")
    app.success("Virtual environment created.")
'''

STORAGE_PY = '''"""Storage configuration for {project_name}."""


def configure_storage(app):
    # Swap "memory" for "json", "sqlite", "yaml", or "toml" as needed.
    return app.storage
'''

SETTINGS_PY = '''"""Settings for {project_name}."""

APP_TITLE = "{title}"
THEME = "dark"
STORAGE_BACKEND = "memory"
'''

GITIGNORE = """__pycache__/
*.pyc
.venv/
.clidev_storage.json
.clidev_storage.db
.clidev_storage.yaml
.clidev_storage.toml
"""

README = '''# {title}

A CLI application built with [clidev](https://github.com/clidev/clidev).

## Run

```bash
python app.py
```

## Structure

- `app.py` - main entry point
- `routes.py` - page routes
- `menus.py` - menu definitions
- `forms.py` - form definitions
- `workflows.py` - workflow definitions
- `commands.py` - shell command helpers
- `storage.py` - storage configuration
- `settings.py` - app settings
- `assets/` - static assets
'''


def create_project(name: str, target_dir: str | None = None) -> Path:
    """Create a new clidev project scaffold named `name`."""
    base = Path(target_dir) if target_dir else Path.cwd()
    project_dir = base / name
    if project_dir.exists():
        raise FileExistsError(f"Directory '{project_dir}' already exists.")

    project_dir.mkdir(parents=True)
    (project_dir / "assets").mkdir()

    title = name.replace("_", " ").replace("-", " ").title()
    ctx = {"project_name": name, "title": title}

    files = {
        "app.py": APP_PY,
        "routes.py": ROUTES_PY,
        "menus.py": MENUS_PY,
        "forms.py": FORMS_PY,
        "workflows.py": WORKFLOWS_PY,
        "commands.py": COMMANDS_PY,
        "storage.py": STORAGE_PY,
        "settings.py": SETTINGS_PY,
        ".gitignore": GITIGNORE,
        "README.md": README,
    }

    for filename, template in files.items():
        content = template.format(**ctx) if "{" in template else template
        (project_dir / filename).write_text(content)

    return project_dir
