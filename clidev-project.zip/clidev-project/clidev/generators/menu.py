"""Helper to scaffold a new menu snippet into menus.py-like files."""

MENU_SNIPPET = '''
{var_name} = app.menu("{title}")
{var_name}.option("Exit", app.exit)
'''


def generate_menu_snippet(title: str) -> str:
    var_name = title.lower().replace(" ", "_")
    return MENU_SNIPPET.format(var_name=var_name, title=title)
