"""Code generators used by the `clidev` CLI command (project/menu/form/workflow)."""

from .project import create_project
from .menu import generate_menu_snippet
from .form import generate_form_snippet
from .workflow import generate_workflow_snippet

__all__ = [
    "create_project",
    "generate_menu_snippet",
    "generate_form_snippet",
    "generate_workflow_snippet",
]
