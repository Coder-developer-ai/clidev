"""Helper to scaffold a new workflow snippet."""

WORKFLOW_SNIPPET = '''
{var_name} = app.workflow("{name}")


def {var_name}_step_one(context):
    app.info("Running {name} step one...")


{var_name}.step({var_name}_step_one)
'''


def generate_workflow_snippet(name: str) -> str:
    var_name = name.lower().replace(" ", "_")
    return WORKFLOW_SNIPPET.format(var_name=var_name, name=name)
