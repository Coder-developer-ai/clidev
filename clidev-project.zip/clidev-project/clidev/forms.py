"""Chainable form builder: app.form("User").text("Name")...run()"""

import uuid

from rich.console import Console
from rich.panel import Panel

from .inputs import Field


class Form:
    """A chainable form. Each `.text()`, `.email()`, etc. call adds a field.

    form = app.form("User")
    form.text("Name")
    form.email("Email")
    data = form.run()
    """

    def __init__(self, title: str = "Form", app=None):
        self.title = title
        self.app = app
        self.id = f"form_{uuid.uuid4().hex[:8]}"
        self.fields: list[Field] = []
        self._console = Console()

    # --- field builders ---------------------------------------------------
    def _add(self, name, kind, **kwargs) -> "Form":
        self.fields.append(Field(name=name, kind=kind, **kwargs))
        return self

    def text(self, name, **kwargs) -> "Form":
        return self._add(name, "text", **kwargs)

    def email(self, name, **kwargs) -> "Form":
        return self._add(name, "email", **kwargs)

    def password(self, name, **kwargs) -> "Form":
        return self._add(name, "password", **kwargs)

    def number(self, name, **kwargs) -> "Form":
        return self._add(name, "number", **kwargs)

    def url(self, name, **kwargs) -> "Form":
        return self._add(name, "url", **kwargs)

    def file(self, name, **kwargs) -> "Form":
        return self._add(name, "file", **kwargs)

    def folder(self, name, **kwargs) -> "Form":
        return self._add(name, "folder", **kwargs)

    def date(self, name, **kwargs) -> "Form":
        return self._add(name, "date", **kwargs)

    def time(self, name, **kwargs) -> "Form":
        return self._add(name, "time", **kwargs)

    def checkbox(self, name, **kwargs) -> "Form":
        return self._add(name, "checkbox", **kwargs)

    def toggle(self, name, **kwargs) -> "Form":
        return self._add(name, "toggle", **kwargs)

    def radio(self, name, choices, **kwargs) -> "Form":
        return self._add(name, "radio", choices=choices, **kwargs)

    def select(self, name, choices, **kwargs) -> "Form":
        return self._add(name, "select", choices=choices, **kwargs)

    def dropdown(self, name, choices, **kwargs) -> "Form":
        return self._add(name, "dropdown", choices=choices, **kwargs)

    def multiselect(self, name, choices, **kwargs) -> "Form":
        return self._add(name, "multiselect", choices=choices, **kwargs)

    def searchable(self, name, choices, **kwargs) -> "Form":
        return self._add(name, "searchable", choices=choices, **kwargs)

    # --- execution ----------------------------------------------------------
    def run(self) -> dict:
        """Render the form interactively, one field at a time, and return a dict."""
        self._console.print(Panel(f"[bold]{self.title}[/bold]", expand=False))
        data = {}
        try:
            for f in self.fields:
                data[f.name] = f.prompt()
        except (KeyboardInterrupt, EOFError):
            return {}

        if self.app is not None:
            self.app.events.emit(f"submit:{self.id}", data)
            self.app.state.update({f"{self.title}.{k}": v for k, v in data.items()})
        return data

    def __repr__(self):
        return f"Form(title={self.title!r}, fields={[f.name for f in self.fields]})"
