"""Individual input widgets used by Form. Rendered via questionary."""

from dataclasses import dataclass, field
from typing import Any, Callable

import questionary

from . import validators as v
from .exceptions import ValidationError


@dataclass
class Field:
    """Represents a single form field/input widget."""

    name: str
    kind: str
    label: str | None = None
    choices: list | None = None
    default: Any = None
    required: bool = True
    extra_validators: list[Callable] = field(default_factory=list)

    def _label(self):
        return self.label or self.name

    def _validate(self, value):
        validators = []
        if self.required:
            validators.append(v.required)
        if self.kind == "email":
            validators.append(v.is_email)
        elif self.kind == "url":
            validators.append(v.is_url)
        elif self.kind == "number":
            validators.append(v.is_number)
        elif self.kind == "date":
            validators.append(v.is_date())
        validators.extend(self.extra_validators)
        return v.run_validators(value, validators)

    def prompt(self):
        """Render this field interactively and return the validated value."""
        label = self._label()

        def _q_validate(raw):
            try:
                self._validate(raw)
                return True
            except ValidationError as e:
                return str(e)

        if self.kind == "text":
            answer = questionary.text(label, default=self.default or "", validate=_q_validate).ask()
        elif self.kind == "email":
            answer = questionary.text(label, default=self.default or "", validate=_q_validate).ask()
        elif self.kind == "url":
            answer = questionary.text(label, default=self.default or "", validate=_q_validate).ask()
        elif self.kind == "password":
            answer = questionary.password(label).ask()
        elif self.kind == "number":
            answer = questionary.text(label, default=str(self.default or ""), validate=_q_validate).ask()
            answer = v.is_number(answer) if answer not in (None, "") else None
        elif self.kind == "date":
            answer = questionary.text(label + " (YYYY-MM-DD)", validate=_q_validate).ask()
        elif self.kind == "time":
            answer = questionary.text(label + " (HH:MM)").ask()
        elif self.kind == "file":
            answer = questionary.path(label).ask()
        elif self.kind == "folder":
            answer = questionary.path(label, only_directories=True).ask()
        elif self.kind == "checkbox":
            answer = questionary.confirm(label, default=bool(self.default)).ask()
        elif self.kind == "toggle":
            answer = questionary.confirm(label, default=bool(self.default)).ask()
        elif self.kind == "select" or self.kind == "dropdown":
            answer = questionary.select(label, choices=self.choices or []).ask()
        elif self.kind == "radio":
            answer = questionary.select(label, choices=self.choices or []).ask()
        elif self.kind == "multiselect":
            answer = questionary.checkbox(label, choices=self.choices or []).ask()
        elif self.kind == "searchable":
            answer = questionary.autocomplete(label, choices=self.choices or []).ask()
        else:
            answer = questionary.text(label).ask()

        if self.kind not in ("number", "checkbox", "toggle", "multiselect"):
            if answer is not None:
                self._validate(answer)
        return answer
