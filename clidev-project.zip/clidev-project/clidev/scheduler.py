"""Lightweight in-process scheduler for delayed / repeating callbacks."""

import threading
import time


class ScheduledJob:
    def __init__(self, interval: float, fn, repeat: bool = False):
        self.interval = interval
        self.fn = fn
        self.repeat = repeat
        self._timer: threading.Timer | None = None
        self._cancelled = False

    def _run(self):
        if self._cancelled:
            return
        self.fn()
        if self.repeat and not self._cancelled:
            self._schedule()

    def _schedule(self):
        self._timer = threading.Timer(self.interval, self._run)
        self._timer.daemon = True
        self._timer.start()

    def start(self):
        self._schedule()
        return self

    def cancel(self):
        self._cancelled = True
        if self._timer is not None:
            self._timer.cancel()


class Scheduler:
    """app.scheduler.after(5, fn) / app.scheduler.every(10, fn)"""

    def __init__(self):
        self.jobs: list[ScheduledJob] = []

    def after(self, seconds: float, fn) -> ScheduledJob:
        job = ScheduledJob(seconds, fn, repeat=False).start()
        self.jobs.append(job)
        return job

    def every(self, seconds: float, fn) -> ScheduledJob:
        job = ScheduledJob(seconds, fn, repeat=True).start()
        self.jobs.append(job)
        return job

    def cancel_all(self):
        for job in self.jobs:
            job.cancel()
        self.jobs.clear()

    def sleep(self, seconds: float):
        time.sleep(seconds)
