"""Conditional-navigation helpers: app.if_value(...).goto(...) and @app.when(...)."""


class ConditionBuilder:
    """Returned by app.if_value(key, **comparisons).

    Usage:
        app.if_value("Role", equals="Admin").goto("admin_menu")
        app.if_value("Age", greater_than=18).goto("adult_menu")

    Supported comparisons: equals, not_equals, greater_than, less_than,
    greater_equal, less_equal, contains, in_list.
    """

    def __init__(self, app, data: dict, key: str, **comparisons):
        self.app = app
        self.data = data
        self.key = key
        self.comparisons = comparisons

    def _value(self):
        return self.data.get(self.key)

    def matches(self) -> bool:
        value = self._value()
        for op, target in self.comparisons.items():
            if op == "equals" and not (value == target):
                return False
            if op == "not_equals" and not (value != target):
                return False
            if op == "greater_than" and not (value is not None and value > target):
                return False
            if op == "less_than" and not (value is not None and value < target):
                return False
            if op == "greater_equal" and not (value is not None and value >= target):
                return False
            if op == "less_equal" and not (value is not None and value <= target):
                return False
            if op == "contains" and not (value is not None and target in value):
                return False
            if op == "in_list" and not (value in target):
                return False
        return True

    def goto(self, page_name: str):
        if self.matches():
            return self.app.goto(page_name)
        return None

    def then(self, fn):
        if self.matches():
            return fn()
        return None


def when(condition_fn):
    """Decorator factory: @app.when(lambda data: data["Role"] == "Admin")

    Wraps `fn` so that calling wrapped(data) only invokes the original
    function if condition_fn(data) is truthy.
    """

    def decorator(fn):
        def wrapper(data=None, *args, **kwargs):
            if condition_fn(data):
                return fn(data, *args, **kwargs) if data is not None else fn(*args, **kwargs)
            return None

        wrapper.__wrapped__ = fn
        wrapper.__condition__ = condition_fn
        return wrapper

    return decorator
