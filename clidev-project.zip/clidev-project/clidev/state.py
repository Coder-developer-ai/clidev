"""Global, dict-like application state: app.state["key"] = value"""

from typing import Any, Callable


class State:
    """A dict-like global state container with optional change listeners."""

    def __init__(self, initial: dict | None = None):
        self._data: dict[str, Any] = dict(initial or {})
        self._listeners: list[Callable[[str, Any, Any], None]] = []

    def on_change(self, callback: Callable[[str, Any, Any], None]):
        """Register a callback(key, old_value, new_value) fired on every set."""
        self._listeners.append(callback)
        return callback

    def __getitem__(self, key):
        return self._data[key]

    def __setitem__(self, key, value):
        old = self._data.get(key)
        self._data[key] = value
        for cb in self._listeners:
            cb(key, old, value)

    def __delitem__(self, key):
        del self._data[key]

    def __contains__(self, key):
        return key in self._data

    def get(self, key, default=None):
        return self._data.get(key, default)

    def update(self, other: dict):
        for k, v in other.items():
            self[k] = v

    def as_dict(self):
        return dict(self._data)

    def clear(self):
        self._data.clear()

    def __repr__(self):
        return f"State({self._data})"
