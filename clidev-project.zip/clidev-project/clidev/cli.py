"""The `clidev` terminal command: project scaffolding utilities."""

import click
from rich.console import Console

from .generators.project import create_project
from . import __version__

console = Console()


@click.group()
@click.version_option(__version__, prog_name="clidev")
def main():
    """clidev: build production-ready CLI apps and TUIs with minimal code."""


@main.command("new")
@click.argument("name")
@click.option("--dir", "target_dir", default=None, help="Parent directory to create the project in.")
def new(name, target_dir):
    """Scaffold a new clidev project called NAME."""
    try:
        project_dir = create_project(name, target_dir)
    except FileExistsError as e:
        console.print(f"[bold red]\u2717[/bold red] {e}")
        raise SystemExit(1)

    console.print(f"[bold green]\u2713[/bold green] Created new clidev project at [bold]{project_dir}[/bold]")
    console.print("\nNext steps:")
    console.print(f"  cd {project_dir.name}")
    console.print("  python app.py")


@main.command("version")
def version():
    """Print the installed clidev version."""
    console.print(f"clidev {__version__}")


if __name__ == "__main__":
    main()
