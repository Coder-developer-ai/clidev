import pytest

from clidev.generators.project import create_project


def test_create_project_scaffolds_expected_files(tmp_path):
    project_dir = create_project("demo_app", target_dir=str(tmp_path))

    expected_files = {
        "app.py", "routes.py", "menus.py", "forms.py", "workflows.py",
        "commands.py", "storage.py", "settings.py", ".gitignore", "README.md",
    }
    actual_files = {p.name for p in project_dir.iterdir() if p.is_file()}
    assert expected_files.issubset(actual_files)
    assert (project_dir / "assets").is_dir()


def test_create_project_fills_in_title(tmp_path):
    project_dir = create_project("my_cool_project", target_dir=str(tmp_path))
    app_py = (project_dir / "app.py").read_text()
    assert "My Cool Project" in app_py


def test_create_project_raises_if_exists(tmp_path):
    create_project("dup_project", target_dir=str(tmp_path))
    with pytest.raises(FileExistsError):
        create_project("dup_project", target_dir=str(tmp_path))
