import pytest

from clidev.router import Router
from clidev.exceptions import NavigationError


def test_page_registration_and_goto():
    router = Router()

    @router.page("home")
    def home():
        return "home rendered"

    assert router.goto("home") == "home rendered"
    assert router.current == "home"


def test_goto_unknown_page_raises():
    router = Router()
    with pytest.raises(NavigationError):
        router.goto("nowhere")


def test_history_and_back():
    router = Router()
    router.page("a", lambda: "A")
    router.page("b", lambda: "B")

    router.goto("a")
    router.goto("b")
    assert router.current == "b"

    router.back()
    assert router.current == "a"


def test_back_with_empty_history_raises():
    router = Router()
    with pytest.raises(NavigationError):
        router.back()


def test_reset_clears_history():
    router = Router()
    router.page("a", lambda: "A")
    router.goto("a")
    router.reset()
    assert router.current is None
    assert router.history == []
