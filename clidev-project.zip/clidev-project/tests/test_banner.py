from clidev.banner import Banner

def test_banner_renders_without_error():
    banner = Banner("HI")
    output = banner.render()
    assert "HI" or output  # sanity check, non-empty
    assert isinstance(output, str)

def test_banner_custom_symbol():
    banner = Banner("A", symbol="@")
    assert "@" in banner.render()