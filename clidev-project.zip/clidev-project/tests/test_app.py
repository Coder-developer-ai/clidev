from clidev import App
from clidev.plugins import Plugin


def test_app_basic_construction():
    app = App("Test App")
    assert app.title == "Test App"
    assert app.theme.get("primary") is not None


def test_app_state_and_storage():
    app = App("Test App")
    app.state["x"] = 1
    assert app.state["x"] == 1
    app.storage.save("y", {"z": 2})
    assert app.storage.load("y") == {"z": 2}


def test_app_page_and_goto():
    app = App("Test App")

    @app.page("home")
    def home():
        return "rendered"

    assert app.goto("home") == "rendered"


def test_app_task_registration_and_run():
    app = App("Test App")

    @app.task
    def build():
        return "built"

    assert app.run_task("build") == "built"


def test_app_use_plugin_installs_and_starts():
    events = []

    class TrackingPlugin(Plugin):
        name = "tracker"

        def on_install(self, app):
            events.append("installed")

        def on_start(self, app):
            events.append("started")

        def on_exit(self, app):
            events.append("exited")

    app = App("Test App")
    app.use(TrackingPlugin())
    assert events == ["installed"]

    app.plugins.start_all()
    assert events == ["installed", "started"]

    app.plugins.exit_all()
    assert events == ["installed", "started", "exited"]


def test_app_cmd_runs_shell_command():
    app = App("Test App")
    result = app.cmd("echo hi", capture=True)
    assert result.ok
    assert "hi" in result.stdout


def test_app_workflow_runs_end_to_end():
    app = App("Test App")
    wf = app.workflow("demo")

    def step_one(context):
        return {"done": True}

    wf.step(step_one)
    result = wf.start()
    assert result == {"done": True}


def test_app_if_value_conditional_navigation():
    app = App("Test App")

    @app.page("admin_menu")
    def admin_menu():
        return "admin!"

    app._last_form_data = {"Role": "Admin"}
    result = app.if_value("Role", equals="Admin").goto("admin_menu")
    assert result == "admin!"


def test_app_notifications_do_not_raise():
    app = App("Test App")
    app.success("ok")
    app.error("bad")
    app.warning("careful")
    app.info("fyi")
