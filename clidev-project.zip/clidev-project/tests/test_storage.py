import pytest

from clidev.storage import Storage
from clidev.exceptions import StorageError


def test_memory_storage_save_and_load():
    storage = Storage(backend="memory")
    storage.save("user", {"name": "Bob"})
    assert storage.load("user") == {"name": "Bob"}


def test_memory_storage_load_default():
    storage = Storage(backend="memory")
    assert storage.load("missing", default="fallback") == "fallback"


def test_memory_storage_delete():
    storage = Storage(backend="memory")
    storage.save("user", {"name": "Bob"})
    storage.delete("user")
    assert storage.load("user") is None


def test_memory_storage_all():
    storage = Storage(backend="memory")
    storage.save("a", 1)
    storage.save("b", 2)
    assert storage.all() == {"a": 1, "b": 2}


def test_json_storage_roundtrip(tmp_path):
    path = tmp_path / "store.json"
    storage = Storage(backend="json", path=str(path))
    storage.save("project", {"name": "clidev", "language": "Python"})
    assert storage.load("project") == {"name": "clidev", "language": "Python"}
    # A fresh Storage instance pointing at the same file should see the data.
    storage2 = Storage(backend="json", path=str(path))
    assert storage2.load("project")["name"] == "clidev"


def test_sqlite_storage_roundtrip(tmp_path):
    path = tmp_path / "store.db"
    storage = Storage(backend="sqlite", path=str(path))
    storage.save("user", {"name": "Alice", "age": 30})
    assert storage.load("user") == {"name": "Alice", "age": 30}
    storage.delete("user")
    assert storage.load("user") is None


def test_yaml_storage_roundtrip(tmp_path):
    path = tmp_path / "store.yaml"
    storage = Storage(backend="yaml", path=str(path))
    storage.save("config", {"debug": True})
    assert storage.load("config") == {"debug": True}


def test_toml_storage_roundtrip(tmp_path):
    path = tmp_path / "store.toml"
    storage = Storage(backend="toml", path=str(path))
    storage.save("config", {"debug": True})
    assert storage.load("config") == {"debug": True}


def test_unknown_backend_raises():
    with pytest.raises(StorageError):
        Storage(backend="mongodb")
