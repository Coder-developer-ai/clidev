"""Tests for clidev.image — TerminalImage sizing/rendering and TerminalVideo timing helpers."""

import pytest

from clidev.exceptions import ClidevError
from clidev.image import SIZE_PRESETS, _resolve_width

PILImage = pytest.importorskip("PIL.Image", reason="Pillow not installed")
cv2 = pytest.importorskip("cv2", reason="opencv-python not installed")

from clidev.image import TerminalImage, TerminalVideo  # noqa: E402


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_image(tmp_path):
    """Create a tiny, deterministic test image on disk."""
    path = tmp_path / "sample.png"
    img = PILImage.new("RGB", (20, 10), color=(255, 0, 0))
    img.save(path)
    return str(path)


# ---------------------------------------------------------------------------
# _resolve_width (shared sizing logic for both images and video)
# ---------------------------------------------------------------------------

def test_resolve_width_uses_named_size_presets():
    assert _resolve_width("small", None, cap=120) == SIZE_PRESETS["small"]
    assert _resolve_width("medium", None, cap=120) == SIZE_PRESETS["medium"]
    assert _resolve_width("large", None, cap=120) == SIZE_PRESETS["large"]


def test_resolve_width_explicit_width_overrides_size():
    assert _resolve_width("large", 55, cap=120) == 55


def test_resolve_width_unknown_size_raises():
    with pytest.raises(ClidevError):
        _resolve_width("huge", None, cap=120)


def test_resolve_width_falls_back_to_terminal_size(monkeypatch):
    import shutil

    monkeypatch.setattr(
        shutil, "get_terminal_size", lambda fallback=(80, 24): type(
            "TS", (), {"columns": 200, "lines": 50}
        )()
    )
    # No size, no width -> falls back to terminal width, capped.
    assert _resolve_width(None, None, cap=120) == 120
    assert _resolve_width(None, None, cap=300) == 200


# ---------------------------------------------------------------------------
# TerminalImage
# ---------------------------------------------------------------------------

def test_terminal_image_requires_pillow(monkeypatch, sample_image):
    import clidev.image as image_module

    monkeypatch.setattr(image_module, "PILImage", None)
    with pytest.raises(ClidevError):
        TerminalImage(sample_image)


def test_terminal_image_default_size_is_medium(sample_image):
    img = TerminalImage(sample_image)
    assert img.size == "medium"
    assert img._target_width() == SIZE_PRESETS["medium"]


@pytest.mark.parametrize("size,expected_width", [
    ("small", SIZE_PRESETS["small"]),
    ("medium", SIZE_PRESETS["medium"]),
    ("large", SIZE_PRESETS["large"]),
])
def test_terminal_image_size_presets(sample_image, size, expected_width):
    img = TerminalImage(sample_image, size=size)
    assert img._target_width() == expected_width


def test_terminal_image_explicit_width_overrides_size(sample_image):
    img = TerminalImage(sample_image, size="large", width=33)
    assert img._target_width() == 33


def test_terminal_image_unknown_size_raises(sample_image):
    img = TerminalImage(sample_image, size="gigantic")
    with pytest.raises(ClidevError):
        img._target_width()


def test_terminal_image_render_produces_output_lines(sample_image):
    img = TerminalImage(sample_image, size="small")
    output = img.render()
    assert isinstance(output, str)
    assert len(output.splitlines()) > 0
    # Every rendered line should reference the half-block character and
    # rgb(...) truecolor styling.
    first_line = output.splitlines()[0]
    assert "rgb(" in first_line
    assert "\u2580" in first_line


def test_terminal_image_show_does_not_raise(sample_image, capsys):
    img = TerminalImage(sample_image, size="small")
    img.show()  # should print without error


# ---------------------------------------------------------------------------
# TerminalVideo
# ---------------------------------------------------------------------------

def test_terminal_video_requires_opencv(monkeypatch):
    import clidev.image as image_module

    monkeypatch.setattr(image_module, "cv2", None)
    with pytest.raises(ClidevError):
        TerminalVideo("clip.mp4")


def test_terminal_video_default_size_is_medium():
    video = TerminalVideo("clip.mp4")
    assert video.size == "medium"
    assert video._target_width() == SIZE_PRESETS["medium"]


def test_terminal_video_size_cap_is_100_not_120():
    # Video caps auto-width at 100 (vs. 120 for images) to help keep
    # real-time playback feasible.
    video = TerminalVideo("clip.mp4", size="large")
    assert video._target_width() == SIZE_PRESETS["large"]


def test_terminal_video_open_missing_file_raises():
    video = TerminalVideo("does_not_exist.mp4")
    with pytest.raises(ClidevError):
        video.play()


def test_terminal_video_frame_to_text_uses_truecolor(sample_image):
    import numpy as np

    video = TerminalVideo.__new__(TerminalVideo)  # bypass __init__ (no real file needed)
    video.size = "small"
    video.width = None

    frame = np.zeros((10, 20, 3), dtype="uint8")
    frame[:, :, 2] = 255  # BGR red

    text = video._frame_to_text(frame)
    assert "rgb(" in text
    assert "\u2580" in text


def test_terminal_video_plays_synthetic_clip(tmp_path):
    """Build a tiny real video file with OpenCV and confirm .play() runs
    without raising, using max_frames to keep the test fast."""
    import numpy as np

    video_path = str(tmp_path / "synthetic.mp4")
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(video_path, fourcc, 24, (20, 10))
    for _ in range(5):
        frame = np.zeros((10, 20, 3), dtype="uint8")
        writer.write(frame)
    writer.release()

    video = TerminalVideo(video_path, size="small", fps=24)
    video.play(max_frames=3)
    assert video.source_fps is not None