import pytest

from clidev import validators as v
from clidev.exceptions import ValidationError


def test_required_passes_for_value():
    assert v.required("hello") == "hello"


def test_required_fails_for_empty_string():
    with pytest.raises(ValidationError):
        v.required("")


def test_required_fails_for_none():
    with pytest.raises(ValidationError):
        v.required(None)


def test_is_email_valid():
    assert v.is_email("abc@gmail.com") == "abc@gmail.com"


def test_is_email_invalid():
    with pytest.raises(ValidationError):
        v.is_email("not-an-email")


def test_is_url_valid():
    assert v.is_url("https://example.com") == "https://example.com"


def test_is_url_invalid():
    with pytest.raises(ValidationError):
        v.is_url("not a url")


def test_is_number_int():
    assert v.is_number("17") == 17


def test_is_number_float():
    assert v.is_number("17.5") == 17.5


def test_is_number_invalid():
    with pytest.raises(ValidationError):
        v.is_number("not-a-number")


def test_min_length():
    validator = v.min_length(3)
    assert validator("abc") == "abc"
    with pytest.raises(ValidationError):
        validator("ab")


def test_max_length():
    validator = v.max_length(3)
    assert validator("abc") == "abc"
    with pytest.raises(ValidationError):
        validator("abcd")


def test_min_value():
    validator = v.min_value(18)
    assert validator(18) == 18
    with pytest.raises(ValidationError):
        validator(17)


def test_max_value():
    validator = v.max_value(100)
    assert validator(99) == 99
    with pytest.raises(ValidationError):
        validator(101)


def test_is_date_valid():
    validator = v.is_date()
    assert validator("2026-07-27") == "2026-07-27"


def test_is_date_invalid():
    validator = v.is_date()
    with pytest.raises(ValidationError):
        validator("not-a-date")


def test_run_validators_chain():
    result = v.run_validators("abc@gmail.com", [v.required, v.is_email])
    assert result == "abc@gmail.com"
