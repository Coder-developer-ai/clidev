import pytest

from clidev.forms import Form
from clidev.inputs import Field
from clidev.exceptions import ValidationError


def test_form_chainable_field_builders():
    form = Form("User")
    (
        form.text("Name")
        .email("Email")
        .password("Password")
        .number("Age")
    )
    names = [f.name for f in form.fields]
    kinds = [f.kind for f in form.fields]
    assert names == ["Name", "Email", "Password", "Age"]
    assert kinds == ["text", "email", "password", "number"]


def test_form_select_and_multiselect_store_choices():
    form = Form("Project")
    form.select("Language", ["Python", "Rust", "Go"])
    form.multiselect("Tags", ["a", "b", "c"])
    assert form.fields[0].choices == ["Python", "Rust", "Go"]
    assert form.fields[1].choices == ["a", "b", "c"]


def test_field_text_validation_required():
    field = Field(name="Name", kind="text", required=True)
    with pytest.raises(ValidationError):
        field._validate("")
    assert field._validate("Bob") == "Bob"


def test_field_email_validation():
    field = Field(name="Email", kind="email", required=True)
    assert field._validate("abc@gmail.com") == "abc@gmail.com"
    with pytest.raises(ValidationError):
        field._validate("not-an-email")


def test_field_number_validation():
    field = Field(name="Age", kind="number", required=True)
    assert field._validate("17") == 17


def test_field_optional_allows_empty():
    field = Field(name="Nickname", kind="text", required=False)
    # required=False means the `required` validator is skipped entirely
    assert field._validate("") == ""


def test_field_extra_validators_applied():
    from clidev.validators import min_length

    field = Field(name="Username", kind="text", extra_validators=[min_length(3)])
    with pytest.raises(ValidationError):
        field._validate("ab")
    assert field._validate("abcd") == "abcd"


def test_form_run_returns_empty_dict_on_interrupt(monkeypatch):
    form = Form("Interruptible")
    form.text("Name")

    def boom():
        raise KeyboardInterrupt()

    monkeypatch.setattr(form.fields[0], "prompt", boom)
    assert form.run() == {}
