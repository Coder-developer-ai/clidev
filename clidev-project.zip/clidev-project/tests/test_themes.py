from clidev.themes import Theme


def test_theme_defaults():
    theme = Theme()
    assert theme.get("primary") is not None
    assert theme.get("success") is not None


def test_theme_fluent_setters():
    theme = Theme()
    theme.primary("blue").success("green")
    assert theme.get("primary") == "#3B82F6"
    assert theme.get("success") == "#22C55E"


def test_theme_preset_dark():
    theme = Theme.preset("dark")
    assert theme.get("background") == "#000000"


def test_theme_preset_light():
    theme = Theme.preset("light")
    assert theme.get("background") == "#FFFFFF"


def test_theme_as_dict_returns_copy():
    theme = Theme()
    d = theme.as_dict()
    d["primary"] = "changed"
    assert theme.get("primary") != "changed"


def test_theme_hex_passthrough():
    theme = Theme()
    theme.primary("#123456")
    assert theme.get("primary") == "#123456"
