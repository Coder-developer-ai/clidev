from clidev.events import EventDispatcher


def test_on_and_emit():
    events = EventDispatcher()
    calls = []
    events.on("start", lambda: calls.append("started"))
    events.emit("start")
    assert calls == ["started"]


def test_on_as_decorator():
    events = EventDispatcher()
    calls = []

    @events.on("exit")
    def handler():
        calls.append("exited")

    events.emit("exit")
    assert calls == ["exited"]


def test_emit_passes_args():
    events = EventDispatcher()
    received = []
    events.on("submit", lambda data: received.append(data))
    events.emit("submit", {"name": "Bob"})
    assert received == [{"name": "Bob"}]


def test_off_removes_handler():
    events = EventDispatcher()
    calls = []

    def handler():
        calls.append("ran")

    events.on("start", handler)
    events.off("start", handler)
    events.emit("start")
    assert calls == []


def test_has_returns_bool():
    events = EventDispatcher()
    assert not events.has("start")
    events.on("start", lambda: None)
    assert events.has("start")


def test_multiple_handlers_all_called():
    events = EventDispatcher()
    calls = []
    events.on("start", lambda: calls.append(1))
    events.on("start", lambda: calls.append(2))
    events.emit("start")
    assert calls == [1, 2]
