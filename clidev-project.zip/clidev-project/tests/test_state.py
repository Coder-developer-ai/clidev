from clidev.state import State


def test_state_set_and_get():
    state = State()
    state["username"] = "Vrushabh"
    assert state["username"] == "Vrushabh"


def test_state_get_default():
    state = State()
    assert state.get("missing", "fallback") == "fallback"


def test_state_contains():
    state = State()
    state["a"] = 1
    assert "a" in state
    assert "b" not in state


def test_state_update():
    state = State()
    state.update({"a": 1, "b": 2})
    assert state.as_dict() == {"a": 1, "b": 2}


def test_state_delete():
    state = State()
    state["a"] = 1
    del state["a"]
    assert "a" not in state


def test_state_on_change_listener():
    events = []
    state = State()
    state.on_change(lambda k, old, new: events.append((k, old, new)))
    state["x"] = 1
    state["x"] = 2
    assert events == [("x", None, 1), ("x", 1, 2)]


def test_state_initial_values():
    state = State({"seed": True})
    assert state["seed"] is True
