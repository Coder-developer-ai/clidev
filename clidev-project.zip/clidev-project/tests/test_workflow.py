import pytest

from clidev.workflow import Workflow
from clidev.exceptions import WorkflowError


def test_workflow_runs_steps_in_order_and_merges_context():
    wf = Workflow(name="test")

    def step1(context):
        return {"a": 1}

    def step2(context):
        assert context["a"] == 1
        return {"b": 2}

    wf.step(step1).step(step2)
    result = wf.start()
    assert result == {"a": 1, "b": 2}


def test_workflow_step_without_args_is_supported():
    calls = []

    def step():
        calls.append("ran")

    wf = Workflow()
    wf.step(step)
    wf.start()
    assert calls == ["ran"]


def test_workflow_initial_context_seeds_first_step():
    def step(context):
        return {"seen": context.get("seed")}

    wf = Workflow()
    wf.step(step)
    result = wf.start(initial_context={"seed": 42})
    assert result["seen"] == 42


def test_workflow_failure_raises_workflow_error():
    def bad_step(context):
        raise ValueError("boom")

    wf = Workflow(name="broken")
    wf.step(bad_step)
    with pytest.raises(WorkflowError):
        wf.start()
