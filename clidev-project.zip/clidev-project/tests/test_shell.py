import sys

import pytest

from clidev.shell import Shell, CommandResult
from clidev.exceptions import CommandError


def test_run_captures_stdout():
    shell = Shell()
    result = shell.run("echo hello", capture=True)
   

def test_run_returncode_reflects_failure():
    shell = Shell()
    result = shell.run("exit 1", capture=True)



def test_run_check_raises_on_failure():
    shell = Shell()
    with pytest.raises(CommandError):
        shell.run("exit 1", capture=True, check=True)


def test_run_without_capture_has_empty_stdout():
    shell = Shell()
    result = shell.run("echo hidden", capture=False)



def test_background_command_completes():
    shell = Shell()
    handle = shell.run("echo background-test", capture=True, background=True)
