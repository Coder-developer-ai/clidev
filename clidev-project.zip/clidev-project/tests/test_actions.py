from clidev.actions import ConditionBuilder, when


class FakeApp:
    def __init__(self):
        self.goto_calls = []

    def goto(self, name):
        self.goto_calls.append(name)
        return name


def test_condition_equals_matches():
    app = FakeApp()
    data = {"Role": "Admin"}
    builder = ConditionBuilder(app, data, "Role", equals="Admin")
    assert builder.matches()
    builder.goto("admin_menu")
    assert app.goto_calls == ["admin_menu"]


def test_condition_equals_does_not_match():
    app = FakeApp()
    data = {"Role": "User"}
    builder = ConditionBuilder(app, data, "Role", equals="Admin")
    assert not builder.matches()
    builder.goto("admin_menu")
    assert app.goto_calls == []


def test_condition_greater_than():
    app = FakeApp()
    data = {"Age": 20}
    builder = ConditionBuilder(app, data, "Age", greater_than=18)
    assert builder.matches()
    builder.goto("adult_menu")
    assert app.goto_calls == ["adult_menu"]


def test_condition_in_list():
    app = FakeApp()
    data = {"Language": "Python"}
    builder = ConditionBuilder(app, data, "Language", in_list=["Python", "Go"])
    assert builder.matches()


def test_condition_then_calls_function_only_if_matches():
    calls = []
    data = {"Role": "Admin"}
    builder = ConditionBuilder(None, data, "Role", equals="Admin")
    builder.then(lambda: calls.append("ran"))
    assert calls == ["ran"]

    calls.clear()
    data2 = {"Role": "User"}
    builder2 = ConditionBuilder(None, data2, "Role", equals="Admin")
    builder2.then(lambda: calls.append("ran"))
    assert calls == []


def test_when_decorator_runs_only_if_condition_true():
    calls = []

    @when(lambda data: data["Role"] == "Admin")
    def admin_handler(data):
        calls.append(data)

    admin_handler({"Role": "Admin"})
    assert calls == [{"Role": "Admin"}]

    calls.clear()
    admin_handler({"Role": "User"})
    assert calls == []
